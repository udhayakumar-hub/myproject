#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
int main()
{
       int a[10];
         
        if(fork()==0)
	  {
	       while(1)
	         {
		       printf("in child process.../n");
		         printf("enter 10 random numberd...../n");
			  scanf("%d",&a);
			    read("


			    }
			       


			      }
			        else
				{
				   printf("in parent process.../n");
				    


