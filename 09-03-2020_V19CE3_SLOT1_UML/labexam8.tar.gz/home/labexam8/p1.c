#include<stdio.h>
#include<string.h>
#include<sys/ipc.h>
#include<unistd.h>
#include<sys/types.h>

struct msgbuf
{
long mtype;
char data[25];

};
int main()
{
int id;
struct msgbuf v;

id=msgget(2,IPC_CREAT|0666);

puts("enter data");
scanf("%s",v.data);
v.mtype=2;
msgsnd(id,&v,strlen(v.data)+1,0);

msgrcv(id,&v,sizeof(v.data),4,0);
printf("msg received from p2 : %s\n",v.data);

}
