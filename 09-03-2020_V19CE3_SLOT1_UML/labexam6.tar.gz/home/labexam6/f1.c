/*NAME : J.VASANTH
  VECTOR ID : V19CE3V1 */


#include<stdio.h>
#include<strings.h>
#include<string.h>
int main()
{
int ch,fd(2);
fd=open("f1",a,O_RDWR);
printf("messages to be shared");
if(fork==0)
{
char a[20];

printf("enter the string ");
if((ch='A'&& ch='Z')||(ch='a'&& ch='z'))
ch= ch^32;
}
write(fd(1),a,strlen(a)+1);
}
else
{
char b[20];
read(fd(0),a,sizeof(a));
printf("enter the string");
write(fd(1),b,strlen(b)+1);
sleep(2);
read(fd(0),b,sizeof(b));

}



