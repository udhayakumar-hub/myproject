#include<stdio.h>
#include<string.h>
#include<sys/msg.h>
#include<stdlib.h>
