//marla naga kalyan
//v19ce3m3
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main()
{
int fd[2];
if(pipe(fd)<0)
{
perror("pipe");
return ;
}
int i=0,j=0,n,status,status1;
srand(time(0));
int a[10];
char ch;
if(fork()==0)
{ 
	while(i++<10)
	{
	printf("enter 'y' or 'Y' to generate random nummber");
	scanf(" %c",&ch);
	n=rand()%5+20; 
	if(ch=='y' || ch=='Y')
	write(fd[1],&n,sizeof(n));
	else
	continue;
	}
	exit(1);
}
else if(fork()==0)
{
	while(j++<10)
	{
	read(fd[0],&n,sizeof(n));
	n=-n;
	printf("2's compliment is:%d\n",n);
	}
	exit(0);
}
else
{
printf("in parent\n");
wait(&status);
wait(&status1);
}
}
