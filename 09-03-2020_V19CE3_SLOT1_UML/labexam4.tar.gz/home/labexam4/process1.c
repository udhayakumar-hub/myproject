	//Mohammed Firoze
	//v19ce3m4
	
	#include<stdio.h>
	#include<sys/types.h>
	#include<stdlib.h>
	#include<string.h>
	int main(int argc,char *argv[])
	{
		if(argc!=2)
		{
			printf("usage: ./a.out string\n");
			return;
		}

		char rdbuf[20];
	//	mkdir("p1",0,O_WRONLY);
		atoi(argv[1]+1);
		msgsnd(1,argv[1],strlen(argv[1])+1,0);
		
	//	rdbuf=msgrcv(1,)
	}	
