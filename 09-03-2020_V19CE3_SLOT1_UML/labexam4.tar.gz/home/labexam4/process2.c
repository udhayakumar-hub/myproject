	//Mohammed Firoze
	//v19ce3m4
	
	#include<stdio.h>
	#include<sys/types.h>
	#include<stdlib.h>
	#include<string.h>
	int main(int argc,char *argv[])
	{
		char rdbuf[20];
		
		rdbuf=msgrcv(1,)
	}	
