/*Name:s.yuvaraj
   id :v19ce3-s7
*/


#include<stdio.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<string.h>
struct msgbuf
{
long mtype;
char mtext[20];
};
int main(int argc, char*argv[])
{
if(argc!=2)
{
printf("usage:./proc2 mtype");
return;
}
int id1=msgget(5,IPC_CREAT|0664);
int id2=msgget(6,IPC_CREAT|0664);
if(id1<0)
{
perror("msgget");
return;
}
int i;
struct msgbuf v;
while(1)
{
msgrcv(id1,&v,sizeof(v.mtext),v.mtype,0);
for(i=0;v.mtext[i];i++)
if(((v.mtext[i]>='A')&&(v.mtext[i]<='Z'))||((v.mtext[i]>='a')||(v.mtext[i]<='z')))
v.mtext[i]=v.mtext[i]^32;
msgsnd(id2,&v,strlen(v.mtext)+1,0);
}
}
