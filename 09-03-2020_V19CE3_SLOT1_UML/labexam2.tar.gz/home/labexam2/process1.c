/*Name:s.yuvaraj
   id :v19ce3-s7
*/


#include<stdio.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<string.h>
struct msgbuf
{
long mtype;
char mtext[20];
};
int main(int argc, char*argv[])
{
if(argc!=2)
{
printf("usage:./proc1 v.mtype\n");
return;
}
int id1=msgget(5,IPC_CREAT|0664);
int id2=msgget(6,IPC_CREAT|0664);
if(id1<0)
{
perror("msgget");
return;
}
struct msgbuf v;
v.mtype=atoi(argv[1]);
v.mtext[20]="vector";
while(1)
{
msgsnd(id1,&v,strlen(v.mtext)+1,0);
sleep(2);
bzero(v.mtext,20);
msgrcv(id2,&v,sizeof(v.mtext),v.mtype,0);
printf("%s\n", v.mtext);
}

}
