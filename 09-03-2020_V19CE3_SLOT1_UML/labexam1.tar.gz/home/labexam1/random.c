//suriya
//v19ce3a6
#include<stdio.h>
#include<unistd.h>
#include<string.h>
int main()
{
 int fd[2],i,ret;
 int a[10],b[10];

 if(pipe(fd)<0)
 {
 perror("pipe:");
 return 0;
 }
 ret=srand();

 if(fork()==0)
 { 
 printf("child process 1:\n");
 for(i=0;i<10;i++)
 a[i]=srand(ret)+2;
 write(fd[1],a,10);
 sleep(2);
 }

 else if(fork()==0)
 {
 printf("child process 2:\n");

 bzero(b,sizeof(b));
 read(fd[0],b,sizeof(b));

 for(i=0;i<10;i++)
 printf("%d ",b[i]);
 printf("\n");
 }

 else
 {
 printf("parent process:\n");
 sleep(1);
 }

}
