//v19ce3g2..//


#include<stdio.h>
#include<pthread.h>
int g=0;
pthread_mutex_t m1=PTHREAD_MUTEX_INITILIZER
void *pthread1=(void *p1)
{
g++;
printf("In thread1,g=%d\n",g);
pthread_mutex_lock(&m1);
sleep(2);
printf("In thread1,g=%d\n",g);
//pthread_mutex_unlock(&m1);
}
void*pthread2(void*p2)
{
printf("In thread2,g=%d\n",g);
pthread_mutex_lock(&m1);
g=10;
sleep(1);
g++;
printf("In thread2,g=%d\n",g);
pthread_mutex_unlock(&m1);
}
int main()
{
pthread_t1,t2;
pthread_create(0,&t1,thread1,0);
pthread_create(0,&t1,thread2,0);
while(1)
}
