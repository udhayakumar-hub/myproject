#include<stdio.h>
#include<strings.h>
#include<string.h>

int main()
 {
   int i,fd[2];
   
  if(pipe(fd)<0)
  {
   perror("no pipe");
   return 0;
  }

   if(fork() ==0)
   {
    char a[10];
    bzero(fd,sizeof(a));
    read(fd[0],a,sizeof(a));
    
    printf("In child: %s\n",a[i]);
     for(i=0;a[i];i++)
     {
       if((a[i]>=0)&&(a[i]<=9))
       
      a[i]= ~(a[i]&1);
     }
    write(fd[1],a,strlen(a));
   }
   
   else
   {
    char b[10];
    printf("In parent: Enter the number:\n");
    scanf("%s",b[i]);

    read(fd[0],b,sizeof(b));  

    write(fd[1],b,strlen(b));
   
    sleep(1);
   
    printf("In parent: %s\n",b[i]);
   }
 } 
