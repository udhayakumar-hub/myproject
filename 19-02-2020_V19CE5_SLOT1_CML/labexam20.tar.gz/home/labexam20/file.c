//abdul baheej m
//v19ce5a3



#include<stdio.h>
#include<stdlib.h>
int main(int argc,char*argv[])
{

	if(argc!=3){
	printf("error\n");
	return 0;}
	
	FILE *fp=fopen(argv[1],"r");
	{if(fp==NULL)
	printf(" file is not presnt\n");
	return 0;}
	
	char ch;
	int c=0;
	
	while((ch=fgetc(fp))!=EOF){
	if(ch==(' ')||('\n'))
	c++;}
	int len;
	len=strlen(argv[2]);

	char buf[len];
	buf[len]=argv[2];
	int i;
	int j;
	char temp;		
	for(i=0,j=len-1;i<j;i++,j--)
	{
	temp=buf[i];
	buf[i]=buf[j];
	buf[j]=temp;
	}
	//FILE *fs=fopen(argv[2],"w");
	//fputs(buf,len,fs)
	
	/*for(i=0;i<c;i++)
	{	fscanf(fp,%s,argv[1]);
		if(fp==argv[2])
		{
		fseek(fp,-len,SEEK_CUR)
		fputs(buf,len,fp)
		}
	}*/
	char *abc=(char *)malloc(len*(sizeof(char)));
	abc=argv[1];
	FILE *fs=fopen(argv[1],"w");
		
	for(i=0;i<c;i++)
	{	
		fscanf(fs,%s,abc);
		if(fs==argv[2])
		{
		fseek(fs,-len,SEEK_CUR);
		fputs(buf,fs);
		}
		else
		fprintf(fs,%s,argv[1]);
		
	
	}



}
