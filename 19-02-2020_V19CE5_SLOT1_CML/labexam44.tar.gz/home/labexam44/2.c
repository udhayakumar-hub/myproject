/*v19ce5s5-->G.Sree valli*/
#include<stdio.h>
int main(int argc,char*argv[])
{
if(argc!=4)
{
printf("Usage:./a.out fs f fd \n");
return 0;
}
FILE*fs;
fs=fopen(argv[1],"r");
if(fs==NULL)
{
printf("file doesn't exist\n");
return 0;
}
char ch1[100];
char ch2[20];
int i,temp,j,k;
printf("enter the word\n");
scanf("%s",ch2);
FILE *fd=fopen(argv[2],"w");
while(ch1=(fgetc(fs))!=NULL)
{
for(i=0;ch1[i];i++)
{
if(ch1[i]==ch2[i])
{
if(ch2[i-1]=='\n')
{
for(j=0;ch2[i];j++)
{
for(k=ch2[i-1];k>=0;k--)
{
temp=ch2[i];
ch2[i]=ch2[i-1];
ch2[i-1]=temp;
}
}
}
}
}
fputs(ch1,fd);
fclose(fd);
fclose(fs);
}
}




