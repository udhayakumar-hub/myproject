//adarsh a
//v19ce5a2
#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{
	if(argc!=2)
	{
		printf("usage: ./a.out <file_name>\n");
		return 0;
	}

int c = 0, i = 0, lines = 0, biglen = 0, bigline = 0, small = 0;
char ch;
FILE *fp = fopen(argv[1],"r");

while ((ch = fgetc(fp))!=EOF)
{
	c++;
	if(ch == '\n')
	{
		
		if(biglen < c)
		{
			biglen = c;
			//bigline = lines;
		
		}
		else if(small < c) 
		small = c; 

		c = 0;
	}
}

rewind(fp);

//char *buf = (char *)malloc(c * sizeof(char));
char buf[biglen+1];

while((ch = fgetc(fp))!=EOF)
{
	buf[i++] = ch;
}
rewind(fp);

int p = 0, k;

FILE* fd = fopen(argv[1],"w");

while((ch=fgetc(fp))!=EOF)
{	
	p++;
 
	if(ch == '\n')
	{	
		lines++;
		
		if(p == biglen)
		{
			//for(k=0; k<lines; k++)
			fputc(buf[biglen],fd);
		}

		biglen--;
		p = 0;
		rewind(fp);
		
	}
	
	 
	else	continue;
	

}
}

		


