//rehana puliyakkuth v19ce5r4
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
if(argc!=2)
{
printf("usage ,/a.out files\n");
return;
}
FILE *fp;
fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("filke doesnot exist\n");
return;
}
int i=0,chsize=0,count=0,line=0,bigline=0,temp,j,k;;
bigline=line;
char *p,ch;
int size=fgetc(fp);
char buf[size],q[11];
//char buf[size]=(char *)malloc(size*sizeof(char));
while(((ch=fopen(argv[1],"r"))!=EOF)&&(i<size))
{
p[i]=fputc(ch,buf[size]);
i++;
}
i=0;
for(i=0;(p!=0)&&(i<size);i++)
{
if((p[i]!='\n')||(p[i]!='\0'))
count++;
else
{
chsize=count;
line++;
}
for(j=0,bigline=0;j<11,bigline;j++)
{
q[j]=chsize;
}

count=0;

}
for(j=0,k=1;j<11,k<11;j++,k++)
if(q[j]>q[k])
{
temp=q[j];
q[j]=q[k];
q[k]=temp;
}
for(i=0;i<11;i++)
{
printf("%d ",q[i]);
}
for(i=0;i<size;i++)
{
if(p[i]=='\n')
line++;
}
for(i=0;i<line;i++)
{

}
}

