
//Name:Rohit Kadam
//ID: V19ce5r11
//cat2.txt 

   #include<stdio.h>
   int main(int argc.char*argv[])
 {
   if(argc!=2)
 {
   printf("Usage:./a.out file\n");
   return 0;
 }
 

   FILE *fp=fopen(argv[1],"r");
   if(fp=NUll)

   printf("file doesn't exist\n");
   return 0;
}   
   char ch;
   int c=0,i=0 ,d=0,j=0
   while ch=fgetc(fp)!=EOF)
{  
   c++;
   if(ch=\n)
   i++;
}

   char p[5]
 
   rewind(fp);
   while ch=fgetc(fp)!=EOF)
   char 
   puts("rev");
   char 
     
   while(fputs=fgetc(fp)!=EOF)
   print("file is exist\n");

}

   for(i=0;i<1;i++)
   printf("%d
   printf("\n");
}
