/*name:sk.mabubasha
  Id:v19ce5m4*/
 #include<stdio.h>
 #include<stdlib.h>
int main(int argc,char*argv[])
{
  if(argc!=2)
   {
     printf("usage:./a.out filename\n");
     return 0;
   }
  FILE*fp=fopen{"filename","r"};
  if(fp==NULL)
   {
     printf("file is doesn't exist\n");
     }
    char ch;
    while((ch=fgets(fp))!=EOF)
  {
    break;
   }
    char*a[20];
    i,n;
    printf("enter n value\n");
    scanf("%s",n);
    for(i=0;i<=n;i++);
    {
      if(i=='\0')
      {
        break;
        i--;
      }
     
    printf("%s",i);
   }
   p=fputs{"buf","fp","w"};
   fputs(buf,fp);
   printtf("%s",buf);
   printf("%s",p);
   
   }
   
  
