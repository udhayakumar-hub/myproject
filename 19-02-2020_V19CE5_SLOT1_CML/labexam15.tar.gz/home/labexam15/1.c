
// v19ce5g2 gokila//
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc!=2)
	{
		printf("./a.out file name\n");
		return 0;
	}
	FILE*fs=fopen(argv[1],"r");
	if(fs==0)
	{
		printf("not exist");
		return 0;
	}
	int count=0,line=0,big_len=0,big_line=0;
	char ch;
	while((ch=fgetc(fs))!=-1)
	{
		count++;
		if(ch=='\n')
		{
			line++;
			if(big_len<count)
			{
				big_len=count;
				big_line=line;
			}
			count=0;
		}
	}
	printf("%d %d %d",line,big_len,big_line);
	char buf[big_len];
	FILE*fd=fopen(argv[1],"w");
	while((fgets(buf,big_len,fd))!=0)
	{
		int i,temp,j;
		for(i=1;buf[i];i++)
		{
			for(j=i+1;j<big_len;j++)
				if(buf[i]>buf[j])
				{
					temp=buf[j+1];
					buf[j+1]=buf[j];
					buf[j]=temp;
				}
			printf("%d",buf[j]);
		}
	}
}

