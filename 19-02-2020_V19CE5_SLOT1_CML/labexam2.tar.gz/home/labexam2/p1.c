//AMRUTHA K.V
//v19ce5a6
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc, char*argv[])
{if(argc!=3)
{printf("usage:./a.out<filename><word>\n");
return 0;}
FILE*fp=fopen(argv[1],"r+");
if(fp==NULL)
{printf("file doesn't exis\n");
return 0;}
int n,i,j,k;
n=strlen(argv[2]);
char a[n],temp;
while((fscanf(fp,"%s",a))!=EOF)
{i=strcmp(a,argv[2]);
if(i==0)
{for(j=0,k=n-1;j<k;j++,k--)
{temp=a[j];
a[j]=a[k];
a[k]=temp;
}
fseek(fp,-n,SEEK_CUR);
fputs(a,fp);
}
}
}


