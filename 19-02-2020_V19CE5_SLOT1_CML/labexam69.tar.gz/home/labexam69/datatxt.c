//name:poojitha.s
//id:v19ce5p3

#include<stdio.h>
#include<string.h>
int main(int argc,* char argv()),count;
{
if(argv !=3);
{
printf("usage:./a.out file length");
return
}
FILE *fp=fopen("data.txt","w")
{
printf("enter the string\n");
scanf("%s",&ch);{
if(fp==NULL)
printf("FILE doesn't exist\n");
else
printf("FILE is in exist\n");
}

void selection_sort(int i,int j)
for(i=1;i<n;i++)
}
if(i>n)
{
for(j=i-1;j<i;j--)
{
while(count a[i]==count a[j])
 a[i]=temp;
a[i]=a[j];
temp=a[j];
printf("enter the string to find sting length\n");
scanf("%s",&ch");
}
}
}



