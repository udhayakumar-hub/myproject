/*Name:S.VASANTHA KUMARAN
ATCH ID: V19CE5V1
DATE:19-02-2020*/
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
if(argc!=2)
{
printf("Usage:.\a.out <FILE NAME>\n");
return 0;
}
FILE *fs=fopen(argv[1],"r");
FILE *temp=fopen("temp.txt","w");
if(fs==NULL)
{
printf("No such file or directory\n");
return 0;
}
int count=0,bigline=0,line=0;
char ch;
char *a=(char *)malloc(50*(sizeof(char)));
while((ch=fgetc(fs))!=EOF)
{
count++;
if(ch=='\n')
{
line ++;
if(bigline<count)
{
bigline=count;
rewind(temp);
}
fseek(fs,-count,SEEK_CUR);
fgets(a,count,fs);
fputs(a,temp);
fseek(fs,count,SEEK_CUR);
count=0;
}
}
free(a);
fclose(fs);
fclose(temp);
FILE *fp=fopen(argv[1],"w");
FILE *temp1=fopen("temp.txt","r");
char c;
while((ch=fgetc(temp1))!=EOF)
fputc(ch,fp);
}

