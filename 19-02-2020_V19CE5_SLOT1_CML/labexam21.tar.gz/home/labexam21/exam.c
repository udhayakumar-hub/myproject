/*name:v.janaki ramana
id:v19ce5v3*/


#include<stdio.h>
int main(int argc,chae**argv)
{
	if(argc!=2)
	{
	printf("usage:./a.out file\n");
	return 0;
	}
	FILE *fp =fopen(argv[1],"r");
	if(fp==NULL)
	{
	printf("file does not exist\n");
	return 0;
	}
	char ch;
	
	int big_length,lines=0,lenth=0,temp=0;
	FILE *fp=fopen(argv[2],"w");
	while(ch=fgetc(fp)!=EOF))
	{
		length ++;
	if(ch='\0')
	{
		lines ++;
	}
	if(big_length<lines)
	{
		big_length=length;
		big_length=lines;
	}
	for(i=0;i<p[i];i++)
	{
	while(ch=fgetc(fp)!=EOF)
	{
		temp=p[1];
		p[1]=p[2;]
		p[2=]temp;
	}
	printf("file is sorted\n");
}
}
}	
