/* name  :Jayachithra
vector ID:V19CE5J1*/
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
if(argc!=2)
{
printf("usage of ./a.out filename\n");
return 0;
}
FILE *fs=fopen(argv[1],"r+");
if(fs==NULL)
{
printf("filedoesnot exist\n");
return 0;
}
char ch,ch1,ch2;
int count=0,lines=0,count1=0,words=0,i,j;
int c,c1;
while((ch=fgetc(fs))!=EOF)
words++;
while(ch=='\n')
lines++;

rewind(fs);
for(i=0;i < lines;i++)
{
while(((ch1=fgetc(fs))!=EOF)&&(ch != '\n'))
c=count++;
for(j=i+1;j < lines;j++)
{
while(((ch2=fgetc(fs))!=EOF)&&(ch != '\n'))
c1=count1++;
}
}
if(c < c1)
fputc(ch1,fs);
else
fputc(ch2,fs);
}


