//v19ce5m9
//M.Sai kiran kumar
#include<stdio.h>
int main(int argc, char *argv[])
{
FILE *fp
=fopen(argc[1],"r")
if(argc!=2)
{
printf("usage:./a.out file name\n");
return 0;
}
FILE *fp=fopen(argc[2],"w")
if(fp==NULL)
{
printf("file doesnot exist\n");
return 0;
}
char ch;
int i, words=0,lines=0;
printf("Enter the string\n");
scanf("%s",&ch);
for(i=2;i<argc;i++)
{
if(argc !=-i)
i++;
while((ch=fgetc(fp))!=EOF)
ch++;
{
if(ch=='\n')
{
lines++;
fgets(fscanf(fp,"%s",i))
words++;
while((ch=fgetc(fp))!=EOF)
rewind(fp);
}
fopen(fp);
fclose(fp);
}
}
}
