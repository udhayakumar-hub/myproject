//v19ce5v5
//vignesh
#include<stdio.h>
sort(char*,int n)
int main()
{
int n;
char lines,file[20];
printf("enter the file to open");
scanf(" %s",file)
fopen("file",W+);
strlen[file];
sort(file,n)
fprintf("%s",file);
fclose(file);
}
sort(char*,int n)
{
int i,n
for(i=0;i<n;i++)
{
if(strlen[i]>strlen[i+1])

}
}
