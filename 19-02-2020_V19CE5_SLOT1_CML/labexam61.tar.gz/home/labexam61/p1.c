//RAJESH RAYAPUDI V19CE5R8
#include<stdio.h>
//#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc!=2){
		printf("usage:./a.out file names");
		return 0;
		}
	int count=0,big_len=0,big_line=0,line=0;
	char ch;
	FILE*fp=fopen("data.txt",argv[1]);
		if(fp=NULL)
		printf("the file doesnot exist\n");
		else
		printf("file is exist");
	while((ch=fgetc(fp))!=EOF)
		count++;
		if(count=='\n')
		line++;
	if(big_line<line)
	{	
		big_len=line;
		big_line=count;
	}
	count=0;
	printf("%d\n",count);
	printf("%d\n",big_line);
	printf("%d\n",big_len);
	printf("%d\n",line);
}	


			

