//R.Kirubakaran
//V19CE5R7

#include<stdio.h>
int main()
{
int a[]="vector";
int i,n,temp,j;
temp=a[i];
n=sizeof a/sizeof a[0];
printf("before reversing a string\n");
for(i=0;i<n;i++)
printf("%d",a[i]);
{
for(i=0,j=n-1;i<j;i++,j--)
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
if(a[i]>a[j])
printf("after reversing\n");
for(j=0;j<n;j--)
printf("%d",a[j]);
}

