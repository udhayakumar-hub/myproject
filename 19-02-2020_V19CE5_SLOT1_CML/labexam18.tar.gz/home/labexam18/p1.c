// name:AISWARYA SAJI
// ID:V19CE5A11

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc,char* argv[])
{

if(argc!=3)
{
 printf("usage ./a.out file givenstring \n");
return 0;
}

FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("file doesnot exist \n");
return 0;
}


char a[20];
strcpy(a,argv[2]);
printf("%s\n",a);
int l=strlen(a);
printf("%d\n",l);
int i,j,temp,s,k;
for(i=0,j=l-1;i<j;i++,j--)
{
 temp=a[i],a[i]=a[j],a[j]=temp;
}
printf("%s \n",a);

char ch;
int c=0;
while((ch=fgetc(fp))!=EOF)
c++;
printf("%d\n",c);
rewind(fp);
char *p=(char *)malloc( c*sizeof(char)+1);
for(i=0;i<c;i++)
{ 
 p[i]=fgetc(fp);
  
}
 printf("%s\n",p);
 rewind (fp);
for(i=0;i<c;i++)
{
  if(p[i]==argv[2][0])
  {
    for(i=i+1,j=1;i<i+(l-2);i++,j++)
   {  
     if(p[i]==argv[2][j])
      {
        
      if(argv[2][j]=='\0')
      
       for(k=i-l,s=0;k<i;k++,s++)
       p[i]=a[s];
      }}}
 else
  break;
}
printf("%s\n",p);
fclose(fp);
FILE *fs=fopen(argv[1],"w");
for(i=0;i<c;i++)
{
 fputc(p[i],fs);
}
free(p);
}

