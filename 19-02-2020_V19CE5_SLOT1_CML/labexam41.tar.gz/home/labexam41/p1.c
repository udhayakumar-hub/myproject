//Name: ASHIN V K
//ID : V19CE5A5

#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	FILE *fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
		printf("Sourse file does not exist\n");
		return 0;
	}
	char ch;
	int c=0,i=0,count=0,j=0;
	int big1,big2,range,line=0,size=0;
	
	
	while((ch=fgetc(fp))!=EOF)
	{
		c++;
		if(ch=='\n')
		line++;
	}
	printf("Total no.of lines = %d\n",line);

	char *buf = (char*)malloc(c*sizeof(char));

	for(i=0;i<line;i++)
	{
		while((ch=fgetc(fp))!=EOF)
		{
			
			size++;
			if(ch=='\n')
			{
				if(big1<size)
				{
					big2=big1;
					big1=size;
				}
				else if(big2<size)
				big2=size;

			range=big2;
			size=0;				
			}
		}
		rewind(fp);
		while((ch=fgetc(fp))!=EOF)
		{
			count++;
			if(ch=='\n')
			{
				if (count>range)
				break;
			}
		}
		fssk(fp,-(count),SEEK_CUR);
		
		while((ch=fgetc(fp))!=EOF)
		buf[j++]=ch;
		count=0;
	}

	fclose(fp);
	fp=fopen(argv[1],"w");

	for(j=0;j<c;j++)
	fputc(buf[j],fp);
	
}
