//v19ce5v9
//replace all the occurences of a given string with reverse of it
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
if(argc!=3)
{
printf("usage ./a.out <filename> <strl>\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("The file doesn't exist\n");
return 0;
}
int chr,i=0;
char ch,ch1,ch2;
while((ch=fgets(fp))!=EOF)
chr=ch;
rewind(fp);
char *p= (malloc)(chr*(sizeof(char));
while((ch=fgets(fp))!=EOF)
p[i++]==ch;
fp=fopen(argv[1],"w");
ch1=argv[2];
ch2=argv[3];
}

