#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
 if(argc!=2){
 printf("usage : ./a.out file\n");
 return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL){
printf("file doesn't exist\n");
return 0;
}
int c=0,big_len=0,big_line=0,lines=0,small_line=0,count=0;
char ch;
while((ch=fgetc(fp))!=EOF)
{
 c++;
 if(ch=='\n')
 lines++;
 if(big_len<c)
 {
  big_len=c;
  big_line=lines;
 }
}
rewind(fp);
 printf("big line=%d\n",big_line);
int i,temp,j;
int a[10];
while((ch=fgetc(fp))!=EOF)
{ 
 count++;
 for(i=0;i<10;i++)
 if(ch=='\n')
 a[i]=count;

 count=0;
}
for(i=0;i<10;i++)
{
 for(j=0;j<9-i;j++)
{
 if(a[i]<a[j])
 {
  temp=a[i];
  a[i]=a[j];
  a[j]=temp;
}
}
}
}


