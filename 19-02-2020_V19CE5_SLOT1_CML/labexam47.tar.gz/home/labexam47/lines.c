  /*  shivakumar N
      v19ce5s6   */

#include<stdio.h>
int main(int argc,char* argv[])
{
	if(argc!=2)
	{	
	printf("usage:./a.out file\n");
	return 0;
	}
FILE *fp=fopen(argv[1],"r");
	if(fp==NULL){
	printf("no such file or directory %s\n",argv[1]);
	return 0;
	}
char ch;
int cnt=0,bigline=0,biglen=0,lines=0;
while((ch=fgetc(fp))!=EOF)
{
	cnt++;
	if(ch=='\n')
	{	
	lines++;
	if(biglen<cnt)
	{
		biglen=cnt;
		bigline=lines;
	}	
	cnt=0;
	}	
}
printf("bigline=%d\n",bigline);
printf("biglen=%d\n",biglen);
printf("lines=%d\n",lines);
}


/*

FILE *fd=fopen(argv[2],"w");
char buf[biglen];
int i;
for(i=0;i<lines;i++)
{
if(buf[i]<biglen)
fputc(biglen,fp);
//else
//fputc(strstr(buf,fs);
}
}
printf("%s",buf);
}

*/
