#include<stdio.h>
int main(int argc,char **argv)
{
if(argc!=3)
printf("usage:./a.out,data.txt,data.txt1\n");
return 0;
}
FILE*fp=fopen("data.txt","r");
if(fp==NULL)
{
printf("file not exist\n");
return 0;
}
char ch,buff[200];
char word;
int size,temp;
FILE*fd=fopen("data.txt1","w");
printf("enter the word to reverse\n");
scanf("%c",&word);
while((ch=fgets(buff,fp,size))!=EOF)
fputs(buff,fd)
fclose(fp);
int i,j;
while(fd==word)
{
for(i=0;i< size;i++)
{
for(j=i-1;j<=i;j--)
temp=i;
i=j;
j=temp;
printf("%s\n",buff);
}
}


