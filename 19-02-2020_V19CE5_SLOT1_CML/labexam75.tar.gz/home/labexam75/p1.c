//nmae-shubham tiwari,v19ce5s3
#include<stdio.h>
#include<string.h>
int main(int argc,char* argv[])
{
if(argc!=2)
{
puts("usage:./a.out file.c");
return 0;
}
FILE*fp=fopen(argv[1],"r");
if(fp==NULL)
{
puts("file dosent exist");
return 0;
}
char ch;
int c=0,i=0,l=1,bl=0,bln=0,j=0,l1=0,d=0,o,k;
while((ch=fgetc(fp))!=EOF)
{
c++;
if(ch=='\n')
l++;
}
rewind(fp);
char buf[c],p[5];
while((fgets(buf,50,fp))!=NULL)
{
d=strlen(buf);
p[i++]=d;
}
rewind(fp);
while((ch=fgetc(fp))!=EOF)
buf[j++]=ch;
buf[j]='\0';
fp=fopen(argv[1],"w");
int small=p[0];
int n=5;
for(o=0;o<l;o++)
{
for(i=1;i<5;i++)
{
if(p[i]<small)
{
bl=i;
small=p[i];
}
}
for(j=0;j<c;j++)
{
if(buf[j]=='\n')
{
l++;
}
if((l==(bl+1))&&(buf[j]!='\n'))
{
fputc(buf[j],fp);
}
break;
}
for(k=i;k<5;k++)
p[i]=p[i+1];

}
}











