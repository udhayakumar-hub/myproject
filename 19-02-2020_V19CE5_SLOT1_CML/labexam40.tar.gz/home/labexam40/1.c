/* NAVYA RAJENDRAN
   V19CE5N1        */

	#include<stdio.h>
	#include<stdlib.h>
	int main(int argc,char *argv[])
	{
		FILE *fp=fopen(argv[1],"r");
		if(fp==NULL)
		{
		printf("Source file does not exist\n");
		return 0;
		}
	char ch;
	int i=0,c=0;

	while((ch = fgetc(fp))!=EOF)
	c++;

	rewind(fp);
	char* buf=(char*)malloc(c * sizeof(char));

	while((ch = fgetc(fp))!=EOF)
	buf[i++]=ch;

	char* stop;
	while(stop = strstr(buf+i,argv[2])!=NULL)
	{
		for(i;i<(stop-buf);i++)
		fputc(buf[i],fp);
		fputs(argv[3],fp);
		i= i+strlen(argv[2]);
	}
	}
