//R.Manoj Kumar(V19CE5M8)
#include<stdio.h>
int main(int argc,char *argv[])
{
if(argc!=2)
{
printf("usage:./a.out file_name\n");
return 0;
}
FILE *fp=fopen("argv[i]","r");
if(fp==NULL)
{
printf("file doesn't exist\n");
return 0;
}
char a[10];
int i,n,count=0;

printf("enter the strings\n");
for(i=0;i<a[n];i++)
scanf(" %c",&a[i]);

if(a[n]=='\0')
{
printf("length of the string\n");
sort(a[n]);
count++;
else
printf("doesn't sort\n");
}
FILE *fp=fopen("argv[1]","w");

while(fgetc(fp)!=EOF)
fputs(fp);
fsave(p);
}

