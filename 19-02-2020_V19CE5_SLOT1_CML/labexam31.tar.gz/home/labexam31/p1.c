//J.JOYCE RAJAM
//v19ce5j3
#include<stdio.h>
#include<stdlib.h>
typedef struct st
struct * right
int main
struct *left
}ST;
void setnum();
void display();
void print();
int main()
{
int n,i,j,p,q,temp,ele;
int a[]={1,7,5,6,4,9};
ele=sizeof a/sizeof a[0];
big1=a[0];
big2=a[1];
ST*hptr=0;
setnum(&hptr);
printf("Enter the numbers\n");
scant("%d",&n);
display (hptr);
print(hptr);
}
void setnum(ST**)
{
 int p,q;
for(i=0;i<n;i++)
{
if(p[i]<q[i])
{
big1=a[0],big2=a[1];
else
big1=a[1],big2=a[0];
}
printf("set the numbers\n");
scanf("%d"&n);
}
}
void display(ST*)
{
if(p[i]=q[i+1])
{
temp=p[i];
p[i]=q[i+1];
q[i+1]=temp;
}
printf("display ascending order\n");
printf("%d\n",p[i]);
}
void print(ST*)
{
for(i=0;i<n;i++)
{
if(q[i]>p[i])
{
p[i]=temp;
}
}
printf("print the order\n");
printf("%d\n",p[i]);
}
