//name:-kishor dhanore
//Id:-v19ce4k3

#include<string.h>
#include<stdio.h>
int main(int argc,char*argv[])
{
	if(argc !=2){
		puts("usage:./a.out file");
		return 0;
	}
	FILE *fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
		puts("file not exist");
		return 0;
	}
	char ch,a;
	int c=0;
	puts("enter the word");
	scanf("%s",&a);
	char buf[190];
//     char*buf= *buf malloc(char*)
	while((ch=fgetc(fp))!=EOF)
	  {
	  c++;
	  }
	  printf("%d\n",c);
//	FILE *fp=fopen(argv[1],"w");
//          fputs(buf,c,fp);
	  }



