//NAME : P.PAVAN KUMAR
//VECTOR ID: V19CE5P4
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc,char* argv[])
{
if(argc!=3)
{
printf("usage:./a.out word \n");
return 0;
}
FILE *fp=fopen(argv[1],"r+");
if(fp==NULL)
{
printf("no such file\n");
return 0;
}
int n;
char ch;
char a[20];
char buff[20];
while((a=fscanf(fp))!=EOF)
n++;
printf("%d",n);

char * p = (char*) malloc (n *sizeof(char*));
fscanf(fp,"%s",a);
printf("%s",a);

strcpy(buff,a);
int i,j,k;
char temp;
i=strlen(buff);
printf("%d",i);
for(j=0,k=i-1;j<k;j++,k--)
{
temp=buff[j];
buff[j]=buff[k];
buff[k]=temp;
}
strcpy(a,buff);
fseek(fp,-i,SEEK_CUR);
fprintf(fp,"%s",a);
free(buff);

}



