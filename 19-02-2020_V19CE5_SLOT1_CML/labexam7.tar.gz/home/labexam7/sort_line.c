/*	Name:Jamuna Tripura
	ID  :v19ce5j2
*/


#include<stdio.h>
int main(int argc,char **argv)
{
	if(argc!=2)
	{
		printf("usage:./a.out  file\n");
		return 0;
	}
	FILE *fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
		printf("file does not exist\n");
		return 0;
	}
	else
		printf("file is exist\n");


	char ch;
	int count=0,line=0,big_line=0,big_len=0;
	while((ch=fgetc(fp))!=EOF)
	{
		count++;
	if(ch=='\n')
	{
		line++;
	
	printf("line=%d\n",line);
	printf("count=%d\n",count);
}
}

/*
		if(big_len<count)
		{
			big_len=count;
			big_line=line;
		}
		count=0;
	}

	printf("count=%d\n",count);
	//printf("big_len=%d\n",big_len);
	//printf("big_line=%d\n",big_line);
	printf("line=%d\n",line);

}
*/

//line++;
//rewind(fp);

char a[20];
int i,j,temp;
for(i=0;i<line-1;i++)
{
	for(j=0;j<line-1-i;j++)
	{
		if(a[i]>a[j])
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}	
}

printf("after sorting lines=%d\n",a[i]);
}

//FILE *fp=fprintf(fp,"%s\n",a);

