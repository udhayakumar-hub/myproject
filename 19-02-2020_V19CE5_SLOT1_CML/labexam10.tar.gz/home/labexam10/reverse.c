/*rushikesh jadhav
v19ce5r9*/
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc!=3)
	{
		printf("usage:./a.out file word\n");
		return 0;
	}
	FILE *fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
		printf("file dosen't exist\n");
		return 0;
	}
	char ch,ch1;
	int i,count=0;
	while((ch=fgetc(fp))!=EOF)
	count++;
	rewind(fp);
	
	char *p=(char *)malloc(count*sizeof (char));
	p[i++]=ch;
		
	ch1=argv[2][0];
	
	char a;
	fp=fopen(argv[2],"w");
	//printf("ENtre the word to reverse\n");
	//scanf("%c",&ch1);
	while((fgets(p,ch,fp))!=NULL)
	if(ch1==p[i])
	{
		p[i]=(p,count-1,SEEK_END);
		if(p!=NULL)
		printf("%s\n",p);	
	fputs(p,fp);
	}
	fclose(fp);
}
