//R.HARIPRIYA
//V19CE5R10
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char* argv[])
{
if(argc!=3)
{
printf("./a.out <file> <word>\n");
return 0;
}
FILE*fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("file does not exist\n");
return 0;
}
char ch;
int biglen=0,bigline=0,count=0,lines=0;
while((ch=fgetc(fp))!=EOF)
{
count++;
if(ch=='\n')
{
lines++;
if(count>biglen)
{
biglen=count;
bigline=lines;
}
count=0;
}
}
printf("%d %d %d %d\n",biglen,bigline,count,lines);
rewind(fp);
int i=0,j,n,k;
char*p[biglen+1];
while((ch=fgetc(fp))!=EOF)
{
p[i++]=ch;
p[i]='\0';
}
while(fgets(p,biglen+1,fp)!=EOF)
for(k=0;p[k];k++)
{
if(p[k]==argv[2])
break;
}
n=strlen(p[k]);
for(j=n-1;j>=0;j--)
printf("%s",p[j]);
fclose(fp);
fp=fopen(argv[1],"w");
fputc(p[j],fp);
}






