/*Holkunde M.M
batch id :v19ce5m1*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc,char* argv[])
{
if(argc!=3)
{printf("usage:./a.out file name string name\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("file not exist\n");
}
int i=0,k=0,j,c=0,len=0,line=0,bigline,biglen;
char ch,ch1;
int n=strlen(argv[2]);
char *s=argv[2];
printf("%s\n",s);
for(i=0,j=n-1;i<j;j--,i++)
{ch1=s[i];
s[i]=s[j];
s[j]=ch1;
}
printf("%s\n",s);

printf("%d\n",n);
while((ch=fgetc(fp))!=EOF)
{c++;
if(ch=='\n')
{line++;
if(biglen<c)
biglen=c;
bigline=line;
}
}

printf("%d\n",c);
rewind(fp);
//char *p=(char*)malloc(c*sizeof(char));
//char *buf,*stop;
//for(i=0;i<c;i++)
/*while(stop=strstr((buf+i),argv[2])
{for(j=buf-stop;j<i;j--)
*/
char *ptr,temp,*p1;
char buf[c-1]; 
while((ptr=fgets(buf,c,fp))!=NULL)
{
/*int r=strcmp(ptr,"vector");
if(r==0)
printf("%s\n",ptr);
else
printf("string not matched\n");
*/
//printf("%s",ptr);
if(ptr=="vector")
{
fseek(fp,-1,SEEK_CUR);
j=ftell(fp);
fseek(fp,-n,SEEK_CUR);
printf("%s",ptr);
i=ftell(fp);
for(;i<j;i++,j--)
{temp=ptr[i];
ptr[i]=ptr[j];
ptr[j]=temp;

printf("%s",ptr);
}
}
fputs(
}
}




