#include<stdio.h>             //ame:rahul baskaran	id:v19ce5r5
int main(int argc,char *argv[])   
{
if(argc!=3)
{
printf("usage:./a.out rahul.txt \n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("file does not exists\n");
return 0;
}
int count=0,i,j,temp;
char c;
while((c=fgetc(fp))!=EOF)
count++;
printf("%d\n",count);
rewind(fp);
FILE *fd=fopen(argv[2],"w");
char buf[30];
while((c=fgets(buf,7,fp))!=EOF)
{
//fseek(fp,-1,SEEK_CUR);
if(buf=="rahul")
{
for(i=5;i>0;i++)
fputc(buf[i],fd);
}
else
fputs(buf,fd);
}
/*while((c=fgetc(fp))!=EOF)
{
if(c=='r')
{
//fseek(fp,-1,SEEK_CUR);
for(i=0,j=2;i<=j;i++,j--)
{
temp=buf[i],buf[i]=buf[j],buf[j]=temp;
fputc(buf[i],fd);
}
break;
}
else
fputc(c,fd);
}*/
fclose(fp);
fclose(fd);
}


