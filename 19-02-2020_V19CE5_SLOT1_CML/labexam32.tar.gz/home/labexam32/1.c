//A.Nehemiya
//v19ce5a15
#include<stdio.h>
#include<string.h>
int (argc,char*argv[])
{
if(argc!=2)
printf("usage:./a.out\n");
return 0;
}
int main()
{
FILE*fp=fopen(argv[1],"r");
if(fp==NULL) {
printf("file doesn't exist\n");
return 0;
}
{
char ch,buf[20],size;
FILE *fp=fgets(buf,size,fp);
printf("enter the size\n");
scanf("size=%d",&size);
printf("buf=%s\n",buf);
printf("fp=%s\n",fp);
{
int i,j,n,temp;
while((ch==(fp))!=NULL)

{
for(i=0,j=n-1;i<j;i++,j++)
{
if(a[i]>a[j])
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
printf("buf=%s\n",buf);
printf("fp=%s\n"fp);
fclose(fp);
}
}
