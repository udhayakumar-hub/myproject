//sri saranya //v19ce5s4//
#include<stdio.h>
int main(int argc,char*argv[])
{
if(argc!=2)
{
printf("error usage:./a.out file\n");
return 0;
}
FILE*fp=fopen(argv[1],"r+");
if(fp==NULL)
{
printf("file doesn't exist\n");
return 0;
}
char ch;
int c,l,bline,blen;
c=l=bline=blen=0;
fp=fopen(argv[1],"r+");
int i=0;
while((ch=fgetc(fp))!=EOF)
{
c++;
if(ch=='\n')
{
l++;
{
if(blen<c)
{
blen=c;
bline=l;
fputc(ch,fp);
}
c=0;
}
}
}
printf("blen=%d\n",blen);
printf("bline=%d\n",bline);
printf("l=%d\n",l);
}
