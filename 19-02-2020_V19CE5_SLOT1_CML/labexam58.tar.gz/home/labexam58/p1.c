
//Akshay ramesh  v19ce5a1

#include<stdio.h>
#include<string.h>
int main(int argc,char* argv[])
{
	if(argc!=4)
	{
		printf("Usage ./a.out file str str\n");
		return 0;
	}
			
	FILE *fp=fopen(argv[1],"r+");
	if(fp==NULL)
	{
		printf("No file\n");
		return 0;
	}

	char ch;
	int count=0,biglength=0;

	while((ch=fgetc(fp))!=EOF)
	{
		count++;
		if(ch=='\n')
		{
			if(biglength<count)
			{
				biglength=count;
			}
			count=0;
		}
	}
	
	char buf[biglength+1];
	int i,j;
	char *p;
	FILE *fd=fopen("m1.txt","w");
	
	while((fgets(buf,biglength,fp))!=NULL)
	{
		p=strstr(buf,argv[2]);
		if(p!=NULL)
		{
			for(i=0;buf[i];i++)
			{
				if(buf[i]==argv[2][0])
				{
				for(j=0;argv[3][j];i++,j++)
				buf[i]=argv[3][j];
				}
			
			}
		}
		fputs(buf,fd);
	}
	rewind(fp);
	fclose(fp);

	FILE *fp=fopen(argv[1],"w");

	char buf1[biglength];
	
	while((fgets(buf1,biglength,fd))!=NULL)
	fputs(buf1,fp);
}
	

	
























	











