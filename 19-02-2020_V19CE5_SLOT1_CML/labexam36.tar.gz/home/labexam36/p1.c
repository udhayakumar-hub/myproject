/* id =v19CE5m7
   name=mahesh satalgaon */
#include<stdio.h>
#include<string.h>
int main(int argc,char *argv[])
{
	if(argc!=3)
	{
		printf("usage:./a.out<file_name><word>\n");
		return 0;
	}
	FILE *fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
		printf("file doesn't exist\n");
		return 0;
	}
	char *p,*s;
	int size=0;
	char ch;
	while((ch=fgetc(fp))!=EOF)
	{
		size++;
	}	
	printf("size=%d\n",size);
      
//       while((s=fgets(buf,size+1,fp))!=NULL)

       //printf("buf=%s\n",s);
	char buf=size+1;
	//p=strstr(buf==argv[2]);
	if(p!=NULL)
		printf("string is prsent\n");
	else
		printf("string is not presnt\n");
        
}
