//HRIDHYA PRAVEEN KUMAR-V19CE5H1
#include<stdio.h>
int main(int argc,char* argv[])
{
if(argc!=2)
{
printf("usage:./a.out,data.txt\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("file do not exist\n");
return 0;
}
char ch;
int count=0,line=0,big_len=0,big_line=0;
while((ch=fgetc(fp))!=EOF)
{
printf("%c",ch);
count++;
if(ch=='\n')
{
line++;
if(big_len<count)
{
big_len=count;
big_line=line;
}
count=0;
}
}
printf("big_len=%d\nbig_line=%d\n",big_len,big_line);
}
