// R.HEMAMALINI V19CE5R3
//2.txt

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc,char*argv[])
{
if(argc!=3)
{
printf("Usage ./a.out file ch\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
printf("File doesn't exist\n");
else
printf("File exists\n");
return 0;
int i,c=0;
char ch[20];
fputs(ch,fp);

while((ch=fgets(fp,size,ch))!=EOF)
c++;
for(i=0;i<c;i++)
{
if(ch==argv[1])
c=strrev(ch,fp);
}
fclose(fp);
}






