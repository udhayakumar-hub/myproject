//NAME: V.VINAY REDDY
//ID: V19CE5V7
//BATCH: CE5
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
if(argc!=3)
{
printf("usage error: ./a.out filename string\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf(" %s is not exist\n",argv[1]);
return 0;
}
int c=0,len=0,i=0,j=0;
char ch; 
while((fgetc(fp))!=EOF)
c++;
rewind(fp);
char* p=(char *)malloc(c*sizzeof(char));
while((ch=fgetc(fp))!=EOF)
p[i++]=ch;
fclose(fp);
for(i=0;argv[2][i];i++,len++);
char* p2=strstr(p,argv[2]);
char* p1=(char*)malloc(len*sizeof(char));
for(i=0;argv[2][i];i++)
p[i]=argv[2][i];
for(i=0,j=len;i<j;i++,j--)
{
ch=p1[i];
p1[i]=p1[j];
p1[j]=ch;
}
FILE *fp=fopen(argv[1],"w");
for(i=0;i<c;i++)
{
if((i<p2)||(i>p2+len))
{
	ch=p[i];
	fgetc(ch,fp);
}
else
{
ch=p1[j++];
fgetc(ch,fp);
}
}
fclose(fp);
}


