//ELBY MARIAM CHANDY
//V19CE5E1
#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
int main(int argc,char *argv[]);
{
if(argc!=2)
{
printf("usage:./aout ch");
return 0;
}}
FILE *fs=fopen(argv[1],"r");
if(fs==NULL)
{
printf("file doesnot exist\n");
return 0;
}
FILE *fd=fopen(argv[1],"w");
char ch;
int count=0,biglen=0,small=0,lines=0;
while((ch=fgetc(fs))!=EOF)
count++;
if(ch=='\n')
{
lines++;
for(i=0;i<lines;i++)
{
if(biglen<count)
{
biglen=count;
//break;
}
else
{
small=count;
}
printf("%d %d\n",small,biglen);
}}




