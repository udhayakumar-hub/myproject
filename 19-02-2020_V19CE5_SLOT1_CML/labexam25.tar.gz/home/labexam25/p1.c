//v19ce5k1
//k.suresh

#include<stdio.h>
int main(int argc,char* argv[])
{
	if(argc<3) {
	printf("usage: ./a.out file\n");
	return 0;
	}

FILE *fp=fopen(argv[1],"r");
if(fp==NULL) {
printf("file dose not exist\n");
return 0;
}
	char ch;
	int linie=0,size=0;
	while(ch!=' ')&&(ch!='\n')
	{	
	size++;
	}		
	if(ch=='\n')
	{
	line++;
	}

while((ch=fgetc(fp))!=EOF)
fclose(fp);

}
int uppercase=0, lowercase=0;
{
if(ch>='A')&&(ch<='Z')
uppercase++;

if else(ch=>'a')&&(ch<='z')
lowercase++

temp=uppercase;
uppercase =lowercase;
lowercase=temp;
}

int srt=sorting(argv[2],"w");
{
if(srt==-1)
printf("file dose not exist\n");
else
printf("sorted successfully\n");
}


