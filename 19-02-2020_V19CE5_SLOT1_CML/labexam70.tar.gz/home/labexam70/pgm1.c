//VANI PRASAD
//V19CE5V6
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc,char*argv[])
{
if(argc!=3)
{
printf("usage:./a.out file name");
return 0;
}
FILE*fp;
fp=fopen("data.txt","r");
if(fp==NULL)
{
printf("file doesnot exist");
return 0;
}
char ch,t;
char a[20];
int i,j,c=0;
while((ch=fgetc(fp))!=EOF)
c++;
rewind(fp);
while((fscanf(fp,"%s",a))!=EOF)
{
if(a==argv[2])
{
for(i=0,j=strlen(a);i<j;i++,j--)
{t=a[i];
a[i]=a[j];
a[j]=t;
}
fp=fopen("data.txt","w");
for(i=0;a[i];i++)
fputc(a[i],fp);
}
}
fp=fopen("data.txt","w");
while((ch=fgetc(fp))!=EOF)
fputc(ch,fp);
}





