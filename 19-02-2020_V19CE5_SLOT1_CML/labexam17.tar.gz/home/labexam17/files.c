//v19ce5s7-sountharya
#include<stdio.h>
int main(int argc,char*argv[])
{
if(argc!=2)
{
printf("usage:./a.out file\n");
return;
}

 
FILE *fp=fopen("data.txt","r");
{
if(fp==NULL)
{
printf("file doesnt exist\n");
return;
}
}

char ch,buf[50],i=0;
int c=0,j,temp;
int bigline=0,biglen=0,l=0;
while((ch=fgetc(fp))!=EOF)
{
c++;
{
if(ch=='\n')
l++;
{
if(biglen<c)
{
biglen=c;
bigline=l;
{
while((ch=fgetc(fp))!=EOF)
if(ch==bigline)
{
buf[i++]=ch;
FILE*fp=fopen("data.txt","w");
fputc(buf[i++],fp);
}
}
}
}
}
}
}


