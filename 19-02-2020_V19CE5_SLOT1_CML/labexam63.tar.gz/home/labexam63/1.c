/*  name : manobala
ID num : v19ce5m3 */


#include<stdio.h>
#include<stdlib.h>
int main()
{

