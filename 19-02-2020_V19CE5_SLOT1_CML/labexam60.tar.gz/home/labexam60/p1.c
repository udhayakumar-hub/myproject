
/*AMAL B
  V19CE5A7*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char buff[50];
char a[50];char temp;
char k[50];
char b[50];
int i,j,m;
int main(int argc,char * argv[])
{
if(argc!=3){ printf("usage issue\n");return 0;}
FILE * fp=fopen(argv[1],"r+");
if(fp==NULL){printf("empty file");return 0;}

for(i=0;argv[2][i];i++){
a[i]=argv[2][i];
b[i]=argv[2][i];}

for(j=0,m=i-1;j<m;j++,m--){
temp=a[j],a[j]=a[m],a[m]=temp;}

while((fscanf(fp,"%s",k))!=EOF)
{
m=strcmp(k,b);
if(m==0)
{
fseek(fp,-i,SEEK_CUR);

fputs(a,fp);
}
}
}


