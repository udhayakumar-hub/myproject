//BIGHOSH KRISHNA R
//V19CE5B1
#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
	if(argc!=2)
	{
	printf("usage:./a.out filename\n");
	return 0;
	}
	FILE *fp=fopen("data.txt","r");
	
	int count=0,lines=0,big_len=0,big_line=0;
	if(fp==NULL)
	{
		printf("no such file or directory\n");
		return 0;
	}	
		char ch,buf[big_len];
	while((ch=fgetc(fp))!=EOF)
	{
		count++;
		if(ch=='\n')
		{
			lines++;
			if(big_len<count)
			{
				big_len=count;
				big_line=lines;
			}
		count=0;
		
		}
	
	}
	fseek(fp,-big_len,SEEK_END);
	fgets(buf,big_len,fp);
	fseek(fp,1,SEEK_SET);
	fputs(buf,fp);

}
