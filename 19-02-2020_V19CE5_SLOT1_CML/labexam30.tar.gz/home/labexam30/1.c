//ALAN SAJI
//V19CE5A19
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc, char * argv[])
{
	if(argc<3){
		printf("Usage: ./a.out filename <string>\n");
		return 0;
		}
	FILE *fp=fopen("argv[1]" ,"r");
	if(fp==NULL) {
		printf("File doesnot exist\n");
		return 0;
		}
	char ch;
	int c=0,i=0;
	while((ch=(fgetc(fp))!=EOF))
		c++;
	rewind(fp);
	char *buf=(char *)malloc(c * sizeof(char));
	while(ch=fgetc(fp)!=EOF){
		buf[i++]=ch;
		}
	fclose(fp);
	FILE *fp=fopen("arg[1]","w");
	char *stop;
	while(stop = strstr((buf+i),arg[2])!=NULL)
	{
		for(i=0;(i<(stop_buf;i++)
			fputs(buf[i],fp);
		fputs(argv[1],fp);
	}
	
}
