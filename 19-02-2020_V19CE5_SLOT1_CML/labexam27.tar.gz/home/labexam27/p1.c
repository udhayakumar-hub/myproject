// k.dayana 
// id:v19ce5k2
#include<stdio.h>
int main(int argc ,char*argv[])
{
if(argc=!2)
{
printf("usage: ./a.out <filename>\n");
return 0;
}
FILE*fp =fopen(argv[1],"r");
if(fp==NULL)
{
printf("file is not exist\n");
return 0;
}
else
{
char ch;
int count=0,biglen=0,size=0;
while((ch=fgetc(fp))!=EOF)
{
if(ch=='\n')
count=0;
if((ch!=' ')&&(ch!='\n'))
{
size++;
count++;
if(biglen < count)
biglen = count;
}
}
printf("c=%d b=%d s=%d \n",count,biglen,size);
}
rewind(fp);
//char buf[size+1];
int newcount=0,i=0;
char ch1;
FILE *fd=fopen("dayana.txt","w");
while((ch1=fgetc(fp))!=EOF)
fputc(ch1,fd);
fp=fopen(argv[1],"w");
while((ch=fgetc(fp))!=EOF)
{
if(ch=='\n')
newcount=0;
if((ch!='\n')&&(ch!='\n'))
{
if(biglen>newcount)



}
}
printf("%c",buf);
*/
}
