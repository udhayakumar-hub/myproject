#include<stdio.h>
#include<string.h>
int main()
{
int l,i,j,count=0;
file (open)"data.txt",w;
printf("The data file to be stored is:\n");
{
for( i=0;i<count;count++)
{
count=count+1;
return 0;
}
save("data.txt")
file(close);
}
