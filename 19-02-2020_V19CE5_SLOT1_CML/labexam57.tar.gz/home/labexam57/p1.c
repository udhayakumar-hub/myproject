//RADHIKA.K  V19CE5R2
#include<stdio.h>
int main(int argc,char *argv[])
{

if(argc!=2)
{
printf("usage:./a.out file\n");
return 0;
}

FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("file not exist\n");
return 0;
}

int lines=0,big_lines=0,big_len=0,c=0,i,j,n;

char ch,t,a[40];

for(i=0;i<n-1;i++)
{
for(j=0;j<n-1-i;j++)
{
if(a[j]>a[j+1])
t=a[j];
a[j]=a[j+1];
a[j+1]=t;
}

while((ch=fgetc(fp))!=EOF)
c++;
{
c++;
if(ch=='\n')
lines++;

else if(big_len<c)
{
big_len=c;
big_lines=lines;
}

}


printf("after sorting based on length\n",argv[1]);
}




