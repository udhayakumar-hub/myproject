//sanket s pateliya
//v19ce5p2
#include<stdio.h>

int main(int argc,char *argv[])
{

	if(argc!=3)
	{
		printf("usage:./a.out filename string\n");
		return;
	}

	FILE *fp=fopen(argv[1],"r+");

	if(fp==NULL)
	{
		printf("file doesn't exist\n");
		return;
	}

	int i,c;
	char ch;

	while((ch=fgetc(fp))!=EOF)
	{

		c=1;
		i=1;

		if(ch==argv[2][0])
		{
			while((ch=fgetc(fp))!=EOF)
			{
				if(ch==argv[2][i])
				{
					i++;
					c++;
				}
                                else
				break;
                        }
		

		fseek(fp,-c-1,SEEK_CUR);

		for(i=c-1;i>=0;i--)
		{
			fputc(argv[2][i],fp);
		}
                }
	}
      

	fclose(fp);
}





