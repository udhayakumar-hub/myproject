//name:- chhipa shaijad m
//vector id:- v19ce5c1

#include<stdio.h>
int main(int argc,char* argv[])
{
  if(argc!=2)
  printf("Usage: ./a.out file_name\n");
  return 0;
}

FILE *fp=fopen(argv[1],'r');

if(fp==NULL)
{
 printf("file doesn't exist\n");
 return 0;
}
char ch;
int count=0,lines=0,big_line=0,big_lengh=0;

while((ch=fgetc(fp))!=EOF)
{
  count++;
  if(ch=='\n')
  {
    lines++;
    if(big_lengh>count)
    big_lengh=count;
 
    big_line=lines;
   
  }
  count=0;
  rewind(fp);
}

FILE *fp=fopen(argv[1],'w');

while((ch=getc(fp))!=EOF)
{
  if(big_line>lines)
  printf(%c,line); 
  else
  continue;
}
