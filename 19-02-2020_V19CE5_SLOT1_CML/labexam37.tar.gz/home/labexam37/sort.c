hi
welcome to vector
practice make man perfect

