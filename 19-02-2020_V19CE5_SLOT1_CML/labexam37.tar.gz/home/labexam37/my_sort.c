
//name:kavya .T
//id:v19ce5k3
#include<stdio.h>
int main(int argc , char*argv[])
{
if(argc!=2)
{
printf("usage:./a.out <filename> \n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("file does not exit \n");
return 0;
}
char ch;
int c=0,l=0,biglen=0,bigline=0;
while((ch=fgetc(fp))!=EOF)
{
c++;
}
/*if(ch==' ')
{
l++;
if(c>biglen)
{
biglen=c;
bigline=l;
}
c=0;
}
printf("l=%d\n",l);
printf("biglen=%d\n",biglen);
printf("bigline=%d\n",bigline);
*/
char temp;
int j,i;
char*p=(char*)malloc(sizeof(char)*c+1);
while((ch=fgetc(fp))!=EOF)
{
p[i++]=ch;
p[i]='\0';
for(i=0;p[i];i++)
{
for(j=0;j<i-1;j++)
{
if(p[i]>p[j])
{
temp=p[i];
p[i]=p[j];
p[j]=temp;
}
}
}
}
fp=fopen(argv[1],"w");
{
for(i=0;p[i];i++)
}
}
