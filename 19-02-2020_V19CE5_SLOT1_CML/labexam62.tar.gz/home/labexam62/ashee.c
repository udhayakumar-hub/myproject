//name:Asheetha Raveendran
//id:v19ce5a14
#include<stdio.h>
#include<string.h>
int main(int argc,char *argv[])
{
if(argc!=3)//provided no of argument count
{
printf("usage:./a.out file string\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");//check given file is existing or not
if(fp==NULL)
{
printf("file doesn't exist\n")
return 0;
}
int i,j,m;
char a[10],b[10];
char temp;

for(i=0;argv[2][i];i++)
{
a[i]=argv[2][i];
b[i]=argv[2][i];
}
for(j=0,m=i-1;j<m;i++,m--)
{
 temp=a[j],a[j]=a[m],a[m]=temp;
}
while((fscanf(fp,"%s",k))!=EOF)//reverse
{
m=strcmp(k,b);
printf("%s",k);
if(m==0)
{
char fseek(fp,-i,SEEk_CUR);
fputs(a,fp);
}
}
char ch;
while((ch=fgetc(fp))!=EOF)
printf("%c",ch);
}

