/* ajai v19ce5a8
replace all the occurrences of a given string with reverse */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(int argc,char* argv[])
{
if(argc!=3)
{
printf("usage:./a.out <filename> <strl>\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("the file doesn't exist");
return 0;
}
int chr,i=0;
char ch,ch1,ch2;
while((ch=fgets(fp))!=EOF)
chr=ch;
rewind(fp);
char *p=(*) (malloc)(chr*(sizeof(char));
while((ch=fgets(fp))!=EOF)
p[i++]==ch;
fp=fopen(argv[1],"w");
ch1=argv[2];
ch2=argv[3];
}


