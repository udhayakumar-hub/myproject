/*	NAME:PANDEY ABHISHEK KUMAR J.
	ID:V19CE5P5


*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc,char *argv[])
{
	if(argc!=3)
	{
		printf("usage:./a.out file  argv[2]...\n");
		return 0;
	}

	char s[30];
	FILE *fs=fopen(argv[1],"r");
	if(fs==NULL)
	printf("file not exist...\n");
	else
	printf("file is exist...\n");

	int words=0;
	while(fscanf(fs,"%s",s)!=EOF)
	{
		words++;

	}
	printf("no of words:%d\n",words);
	rewind(fs);
	words++;

	char *buf=(char *)malloc(words*sizeof(char));
	if(buf==NULL)
	{
		printf("memory is  not allocated...\n");
		return 0;
	}

	int c,k=0;
	while((c=fgetc(fs))!=EOF)	
	
		buf[k++]=c;

		buf[k]='\0';


	printf("%s\n",buf);
//	fclose(fs);
/*

	FILE *fd=fopen(argv[1],"w");
	int i=0,j;
	char *stop;

	while((stop=strstr(buf+i,argv[2]))!=NULL)
	{
		for(j=stop-buf;i<j;i++)
		fputc(buf[i],fd);
		


		
		
		


	}
	
*/	








}
