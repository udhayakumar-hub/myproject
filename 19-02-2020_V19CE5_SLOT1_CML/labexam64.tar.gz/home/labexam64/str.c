//v19ce5r13
//Radha Rani


#include<stdio.h>
int main(int argc,char *argv[])
{
     if(argc != 2)
     {
          printf("Usage:./a.out file\n");
          return 0;
     }

     FILE *fs = fopen(argc[1],"r");
    i
     if(fs == NULL)
     printf("file doesn't exist\n");
     else
     printf("file exists\n");

    char s[] = "vector india";
    int i,j,n,temp;
    n = sizeof s/sizeof s[0];
    for(i=0;i<n;i++)  
    {
        for(j=0;j<n-1;j++)
        { 
            if(s[i]<s[j])
            {
                   temp = s[i];
                   s[i] = s[j];
                   s[j] = temp;
            }
            else
            s[i] = s[j];
        }
    }
    
    FILE *fp = fopen(argv[1],"w");
   
    if(s[i] != s[j])
    {
    printf("replace the string\n"); 
    else
    return 0;
    }
    if(s[j] = '\0');
    printf("string is %s\n",s[i]);
}    
