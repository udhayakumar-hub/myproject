// Rohit v19ce5r12
#include<stdio.h>
int main(int argc,char *argv[])
{
	if(argc!=2)
	{
		printf("usage:./a.out file\n");
		return 0;
	}
	char ch;
	int i,j,temp;
	int count=0,biglen=0,lines=0;
	FILE *fp=fopen("file1.c","r");
	while((ch=fgetc(fp))!=EOF)
	{
		count++;
		if(ch=='\n')
		{
			lines++;
			if(biglen<count)
			{
				biglen=count;
				
			}
			count=0;
		}
		
	}
	printf("lines=%d\n",lines);
	printf("biglen=%d\n",biglen);
}
