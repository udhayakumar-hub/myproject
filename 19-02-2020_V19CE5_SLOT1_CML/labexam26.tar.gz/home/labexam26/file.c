/*name :renjini.c
 vector id: v19ce5r6
exam id : labexam26 
*/


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct student
{
int;
char;
float;
char*s[];
}ST;
int main()
{
ST* = ST*(malloc(file name, sizeof(S));
FILE *fopen(fptr*ST, char*);
FILE(fptr==NULL);
printf("file does not fount\n");
printf("Enter the data\n");
printf("Enter the string to be replace\n");
scanf("%s",s);
FILE *fopen(fptr*ST,char*);
int i,j;
for(i=0;d[i],i++)
{
FILE *fptr,*ptr;
fptr=0;
if(s[o]!=d[i])
fclose();
else if(s[0]==d[i])
{
for(j=1,s[j],j++,i++)
if(s[j]!=d[i+1])
else
{
d[i+1]==d[i+2];
}
}
fptr++
printf("Given string does not fount\n");
ptr++
fclose();
}
fptr++;
}
}
