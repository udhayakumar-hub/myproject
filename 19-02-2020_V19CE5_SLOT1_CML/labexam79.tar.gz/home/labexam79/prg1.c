
/*aleena mathew
v19ce5a18*/


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(int argc ,char*argv[])
{
if(argc!=2)
{
printf("usage:./a.out filename\n");
return 0;
}
FILE *fp=fopen(argv[1],"r");
if(fp==NULL)
{
printf("no such file\n");
return 0;
}
char ch;
int c=0,sm_len=20;
while((ch=fgetc(fp))!=EOF)
{
c++;
if(ch=='\n')
{
if(c<sm_len)
{
sm_len=c;
c=0;
}}
}
printf("%d\n",sm_len);
}

rewind(fp);


char *p=(char *)malloc((sizeof(char)*c)+1);
FILE *fd=fopen(argv[1],"r");
while(ch=fgetc(fd)!=EOF)
p[i++]=ch;


char *tem,temp;
int i,j;
for(i=0;i<10;i++)
{
for(j=0;p[j];j++);
if(j=sm_len)
{
&temp=p[0];;
p[0]=p[i];
p[i]=&temp;
}
if(j>sm_len)
{
for
{(k=i;k<10;k++)
if(p[k]>j)
{
strcpy(&tem,p[k]);
strcpy(p[k],p[i]);
strcpy(p[i],&tem);
}}}
}


FILE *fn=fopen("argv[1]","w");
{
for(i=0;i<50;i++)
fputc(fn,buf[i]);
}

