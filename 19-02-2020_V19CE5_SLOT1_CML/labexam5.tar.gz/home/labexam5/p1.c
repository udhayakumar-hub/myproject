// Name : Pratik Nawale
// ID : V19CE5N2

#include<stdio.h>
void sort(FILE*fp);
int main(int argc,char *argv[])
{
	if(argc!=2){
	printf("Usage : ./a.out file\n");
	return 0;
	}
	FILE *fp=fopen(argv[1],"r");
	if(fp==NULL){
	printf("File does not exist in system..\n");
	return 0;
	}
	char ch;
	int length=0,line=0,words=0;
	while((ch=fgetc(fp))!=EOF)
	{
		length++;
		if(ch=='\n')
		line++;
	}
	printf("length : %d\n line : %d\n",length,line); 
	FILE*n=sort(fp,line);
	printf("%c",n);
	printf("\n");
}
void sort(FILE*fp,int line)
{
char c;
int len=0,i;
for(i=0;i<line;i++)
{
	while((c=fgetc(fp))!='\n'){
	len1++;}
}

}
