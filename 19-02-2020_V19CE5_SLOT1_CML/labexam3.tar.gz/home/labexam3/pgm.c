//saranya
//v19ce5s1



#include<stdio.h>
#include<stdlib.h>
int main()
{
int i,j;
FILE *fp=fopen("data.txt","r");

if(fp==0)
{
printf("file not exisr\n");
return 0;
}
char ch,big_len=0,line=0,count=0,big_line=0;
while((ch=fgetc(fp))!=EOF)
{
count++;
if(ch=='\n')
{
line++;

if(big_len<count)
{
big_len=count;
big_line=line;
}
count=0;
}
}
printf("big_len=%d\n",big_len);
printf("big_line%d\n",big_line);



rewind(fp);
char*p=(char*)malloc(big_len*sizeof(char));
i=0,count=0;
while((ch=fgetc(fp))!=EOF)
{
count++;
if(ch=='\n')

{
line++;

p[i++]=count;
printf("%d\n",p[i]);
 
}
count=0;
}



int temp;


for(i=0;i<big_len-1;i++)
{
for(j=0;j<big_len-i-1;j++)
{
if(p[j]>p[j+1])
{
temp=p[j];
p[j]=p[j+1];
p[j+1]=temp;
}
}}

for(i=0;i<big_len;i++)
printf("%d",p[i]);




fclose(fp);
fp=fopen("data.txt","w");
fputc(p,fp);
fclose(fp);
}



