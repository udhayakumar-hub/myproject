	// ID:V9CE5A10
	// ADARSH.K.P
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc!=2)
	{
		printf("Usage:./a.out data.txt\n");
		return 0;
	}

FILE *fp=fopen(argv[1],"r+");
	if(fp==NULL)
	{
		printf("File does not exist\n");
		return 0;
	}

char ch;
int line=0,c=0,i=0,j,size,temp;


while((ch=fgetc(fp))!=EOF)
	c++;
rewind(fp);
char *buf1=(char *)malloc(c*sizeof(char));
char *buf2=(char *)malloc(c*sizeof(char));

fputs(buf1,fp);
for(i=0;buf1[i];i++)
{
	while(buf1[i]!='\n')
	line++;
	buf2[i]=line;
}
for(i=0;buf2[i];i++)
printf("%d",buf2[i]);
size=sizeof(buf2)/sizeof(buf2[0]);
for(i=0;i<size-1;i++)
	{
		for(j=0;j<size-i-1;j++)
		{
			if(buf2[j]>buf2[j+1])
			{
				temp=buf2[j];
				buf2[j]=buf2[j+1];
				buf2[j+1]=temp;
		
			}
		}
	
	}
fputs(fp,buf2);

}
