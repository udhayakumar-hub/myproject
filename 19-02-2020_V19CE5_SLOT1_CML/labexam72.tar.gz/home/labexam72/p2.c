#include<stdio.h>
#include<string.h>
int main()
{
char str[100],sub[20];
printf("Enter the string\n");
scanf("%[^\n]",str);
printf("Enter the substring\n");
scanf("%s",sub);
//printf("%p",sub);
char* p=strstr(str,sub);
int r=strlen(str);
printf("%d\n",r);
int i,j,temp;
//printf("%p",p);
if(p!=0)
{
printf("Substring is present\n");
printf("Entering into substring loop\n");
for(i=0,j=0;str[i]!='\0';i++)
{
//printf("%d",i);
//for(j=0;sub[j]!='\0';)
{
//printf("%d",j);
//pintf("%c %c",str[i],sub[j]);
if(str[i]==sub[j])
{
j++;
i++;
}
else
j=0;
break;
}
//printf("i=%d j=%d",i,j);

if(j!=0)
{
int k;
int l=i-1;
//printf("%d",k);
//printf("%d",l);
for(k=i-1;k!=' ';k--);
k=k-1;
for(;i<j;k++,l--);
{
temp=str[k];
str[k]=str[l];
str[l]=temp;
}
}


}
printf("%s",str);
}
//printf("%s",str);
else
printf("substring not present\n");
}
