// aashwin shyam v19ce5a4
#include<stdio.h>
#include<string.h>
int main(int argc,char** argv)
{if(argc!=3)
{
printf("usage:./a.out src file\n");
return 0;
}
char a[100];
int i,j,m,x,t;
x=strlen(argv[2]);
FILE*fp;
fp=fopen(argv[1],"r+");
if(fp==0)
{
printf("file doesnt exist\n");
return 0;
}


while(fscanf(fp,"%s",a)!=NULL)
{m=strcmp(a,argv[2]);
if(m==0)
{
for(i=0,j=x-1;i<j;i++,j--)
{
t=a[i],a[i]=a[j],a[j]=t;
fseek(fp,-x,SEEK_CUR);
fputs(a,fp);
}
}
}
}



