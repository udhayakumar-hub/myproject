// id=v19ce5b3   name=jayesh


#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
	if(argc<2){
		printf(" usage: ./a.out <file_name>\n");
		return 0;
	}
	FILE*fm=fopen(argv[1],"r");
	if(fm==NULL){
		printf(" %s is not exist \n",argv[1]);
		return 0;
	}
	int c=0,lines=0,big_len=0,big_line=0,word=0;
	char ch;
	while((ch=fgetc(fm))!=EOF)
	{
		c++;
		if(ch=='\n')
		{
			lines++;
			if(c > big_len)
			{
				big_len=c;
				big_line=lines;				
			}
		}
	}
		
	printf("char=%d\n",c);
	printf("big_length=%d\n",big_len);
	printf("No of lines=%d\n",lines);
	
	rewind(fm);
	int i;
	char p[c];
	while((ch=fgetc(fm))!=EOF)
	{
	if((ch==' ')||(ch=='\n'))
	word++;
	}
	printf("words=%d\n",word);
	printf("big_line=%d\n",big_line);
}
