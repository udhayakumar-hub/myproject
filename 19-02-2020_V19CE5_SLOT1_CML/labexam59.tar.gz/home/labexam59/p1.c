/*----V.ADIRA------*/
/*----V19CE5V2-----*/

#include<stdio.h>
#include<stdlib.h>
int main(int argc,char *argv[]){
if(argc!=2)
{
printf("usage:./a.out <file>");
return 0;

}
FILE*fp=fopen(argv[1],"r");
if(fp==NULL){
printf("the file does not exist");
return 0;
}
int line=0,biglength=0,bigline=0,count=0;
char ch;

while((ch=fgetc(fp))!=EOF){
count++;
if(ch=='\n')
line++;

if(count>biglength){
biglength=count;
bigline=line;
}
count=0;
}
rewind(fp);
int i=0,temp;
char buf[20];
while((ch=fgetc(fp))!=EOF){

count++;
if(ch=='\n')
line++;

for(i=0;i<biglength-1;i++){
if(line>biglength){
temp=biglength;
biglength=line;
line=temp;
}
buf[i]=ch;
}
FILE*fs=fopen(argv[1],"w");
fputc(buf[i],fs);
fclose(fp);
fclose(fs);
}
}






