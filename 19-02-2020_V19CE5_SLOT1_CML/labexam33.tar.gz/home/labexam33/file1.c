//G.manoj kumar
//v19ce5g1
#include<stdio.h>
int main(argc,char*argv[]);
{
if(argc!=4)
printf("usage:.a/.out\n");
return 0;
FILE*fp=fopen(argv[1],"r");
if(fp=NULL)
printf("file doesn't exist\n");
}
return 0;
int c,ch1,ch2;
ch1 argv[2][0];
ch2 argv[3][0];
FILE*fp=fd(argv[2],"w");
if(fd==0)
while((fgetc(fd)!=0)&&(EOF==-1))
fgetc(fd,seek,-1);
fgetc(fd);
fclose();
}









