/* NAME:  ATHULYA S
  BATCHID: V19CE5A16
  DATE: 19/02/2020
*/
#include<stdio.h>
int main(int argc,char**argv)
{
	if(argc!=2)
	{
		printf("usage:./a.out file\n");
		return 0;
	}
	FILE*fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
		printf("file doesnt exist\n");
		return 0;
	}
	int c=0,big_len=0,big_line=0,lines=0;
	char ch;
	while((ch=fgetc(fp))!=-1)
	{
 	c++;
       	if(ch=='\n')
	{
	lines++;
		if(c>big_len)
		big_len=c;
		big_line=lines;
		
	}
	}
	c=0;
	rewind(fp);
	printf("big_len=%d\n",big_len);
	printf("big_line=%d\n",big_line);
int i;
for(i=0;i<big_line;i++);
for(i=big_line;i>=0;i--)
{
	FILE*fp=fopen(argv[1],"w");
	fputc(ch,fp);
	fclose(fp);
}
}
