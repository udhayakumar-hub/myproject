/*NAME: A.CHRISTIE AISWARYA
    ID: VI9CE5A9*/
#include<stdio.h>
#include<string.h>
int main(int argc,char *argv[])
{
	if(argc!=3)
	{
		printf("usage:./a.out data.txt vector\n");
		return;
	}
FILE *fp=fopen(argv[1],"r+");
	if(fp==NULL)
	{
		printf("file doesn't exist\n");
		return;
	}	
char *w=argv[2],a[20],temp;
int l,i,j,s;
l=strlen(w)-1;
	while(fscanf(fp,"%s",a)!=EOF)
	{
		s=strcmp(w,a);
	if(s==0)
	{
		fseek(fp,-(l+1),1);
		for(i=0,j=l;i<j;i++,j--)
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	fputs(a,fp);
	}
}
fclose(fp);
}

