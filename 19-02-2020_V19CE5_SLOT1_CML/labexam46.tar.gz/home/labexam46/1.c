/*	NAME : SAMPATHKUMAR.C
	ID   : V19CE5S2		*/
#include<stdio.h>
#include<string.h>
int main(int argc,char *argv[])
{
	char ch,temp;
	int c=0,i,j,k,l=0;
	if(argc!=3)
	{
		printf("missing some files\n");
		return 0;
	}
	FILE *fs=fopen(argv[1],"r");
	if(fs==NULL)
	{
		printf("file doesn,t exist\n");
		return 0;
	}
	while((ch=fgetc(fs))!=EOF)
	{
		c++;
		printf("%c",ch);
	}
	char buf[c+2];
	rewind(fs);

	c=0;
	while((ch=fgetc(fs))!=EOF)
	{
		buf[c++]=ch;
	}
	buf[c]='\0';
	c=strlen(argv[2]);
	for(i=0;buf[i];i++)
	{
		if(argv[2][0]==buf[i])
		{
			for(k=i,j=0;buf[k++]==argv[2][j++];++l);
			if(l==c)
			{
				for(k=i,j=k+c-1;k<j;k++,j--)
				{
					temp=buf[k];
					buf[k]=buf[j];
					buf[j]=temp;
				}
				i=i+c-1;

			}
		}
	}
	FILE *fp=fopen(argv[1],"w");
	i=0;
	printf("%s\n",buf+0);

	for(i=0;buf[i];i++)
	{
		ch=buf[i];
		fputc(ch,fp);
	}
}
