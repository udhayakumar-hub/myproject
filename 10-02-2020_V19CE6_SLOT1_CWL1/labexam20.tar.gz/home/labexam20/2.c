//Ashil shaji,v19ce6a3
#include<stdio.h>//adding header file
int main()
{
int i,j;//declaring i and j as integers
for(i=1;i<=10;i++)
{
for(j=1;j<=10;j++)
printf("%d x %d=%d\n",i,j,i*j);
printf("\n");
}
}
