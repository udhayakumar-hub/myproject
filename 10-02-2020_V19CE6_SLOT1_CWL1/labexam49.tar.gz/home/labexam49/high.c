//rakul.r
//v19ce6r1
#include<stdio.h>
int main()
{
 int n,temp,a=0,b=0;
 printf("Enter the n value\n");
 scanf("%d",&n);
while(temp!=0)
 {
  temp=temp%10;
  
}


printf("%d\n",s);
} 
