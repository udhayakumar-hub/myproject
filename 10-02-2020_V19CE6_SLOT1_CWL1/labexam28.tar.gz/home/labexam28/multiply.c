/*name:R.ARUN KUMAR
vector id:v19ce6r3*/
#include<stdio.h>
int main()
{
  int i,t;
 printf("enter the n value");
 scanf("%d",&n);
 i++;
 while
     (n*1*10)
  for(i=1;i<=10;i++)
  {
    i=n;*10;
    t=n/10;
  }
 if(t==i)
else
  printf("%d",n);
}

