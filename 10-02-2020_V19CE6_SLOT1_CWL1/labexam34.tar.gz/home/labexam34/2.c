//Z. SHATHIK HUSSAIN - CE6S10

#include<stdio.h>
int main()
{
int i,n=1,r;

for(;n<=10;n++)
{
for(i=1;i<=10;i++)
{
r=i*n;
printf("%d*%d=%d ",n,i,r);
}
printf("\n");
}
}




