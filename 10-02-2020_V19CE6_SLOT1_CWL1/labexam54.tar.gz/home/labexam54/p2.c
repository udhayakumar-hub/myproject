//R.mohan raj
//v19ce6r2
//multipilication table
#include<stdio.h>
int main()
{
int n,i;
printf("enter the number\n");
scanf("%d",&n);
for(i=1;i<=10;i++)
printf("%d*%d=%d\n",n,i,n*i);
}
