//Name     : M.Balaji
//Batch id : v19ce6b2

#include<stdio.h>
int main()
{
int n,i,n1,count=0;
printf("enter the n value");
scanf("%d",&n);
n1=n;
while(n1!=0)
{
n1=n1/t;
count++;
}
for(i=1;i<count;i++)

