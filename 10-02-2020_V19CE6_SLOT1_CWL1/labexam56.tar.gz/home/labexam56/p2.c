//NAME      : M.Balaji
// Batch id : v19ce6b2
#include<stdio.h>
int main()
{
int i,j;
for(i=1;i<=10;i++)
{
for(j=1;j<=12;j++)
{
printf("%d*%d = %d\n",i,j,i*j);
}
printf("\n");
}
}
