//G.SANGEETHA-V19CE6S11-MULTIPLICATION TABLE//
#include<stdio.h>
int main()
{
int i,n;
printf("enter the n value\n");
scanf("%d",&n));
if(i<=n)
n=n*i;
i++;
}
printf("i=%d n=%d n*i=%d\n",i,n,i*n);
}

