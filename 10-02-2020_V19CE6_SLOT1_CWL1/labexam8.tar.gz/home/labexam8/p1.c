//v19ce6m1 qst no; 2
#include<stdio.h>
int main()
{
int n,i,j;
for(n=1;n<=10;n++)
{for(i=1;i<=10;i++)
{
printf("%d * %d=%d\n",n,i,n*i);

}
}}
