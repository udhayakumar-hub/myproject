/*
NAME: NIRMAL RAGAVAN R
VECTOR ID: V19CE6N3
*/
#include<stdio.h>
int main()
{
int a,i,j;
//printf("enter the number for multiplication\n");
//scanf("%d",&a);
for(j=1;j<=10;j++){
for(i=1;i<=10;i++)
{
printf("%d*%d=%d\n",j,i,j*i);
}}
}
