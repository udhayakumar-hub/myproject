// Name:S.Lingeshkumar
//Batch:v19ce6l1
#include<stdio.h>
int main()
{
int n,s=0,r;
printf("enter n value \n");
scanf("%d",&n);
while(n!=0)
{
r=n%10;
s=s*r;
n=n/10;
}
printf("the second highest digit..");
printf("\n");}
}
