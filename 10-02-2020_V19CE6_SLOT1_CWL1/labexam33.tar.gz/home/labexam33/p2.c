#include<stdio.h>
int main()
{
int i,n,r,s=0;
printf("enter the n value\n");
scanf("%d",&n);
while(n!=0)
{
r=n%10;
s=r
n=n/10;
}
printf("s=%d\n",s);
}

