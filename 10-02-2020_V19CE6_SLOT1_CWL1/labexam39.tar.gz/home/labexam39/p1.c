//v19ce6j2_JERON MELVA>S Q
#include<stdio.h>
int main()
{
int n,s=0,a,r;
printf("enter the number\n");
scanf("%d",&n);
while(n!=0)
{
r=n%10;
s=r;
s<r;
n=n/10;

}
if((r>n)&&(r<n))
{
printf("2nd highest didit");
}
else
{
r++;
}
}
