
#include<stdio.h>         //Name: K.Dhinesh Kumar ID:V19CE6D2
int main()
{
int i,j,t;
for(i=1;i<=10;i++)
{
for(j=1;j<=10;j++)
{
t=i*j;
printf("%d * %d= %d\n",i,j,t);
}
printf("******************\n");
}
}


