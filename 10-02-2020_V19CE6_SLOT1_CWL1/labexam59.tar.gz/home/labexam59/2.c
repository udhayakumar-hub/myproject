#include<stdio.h>
int main()
{
int n,r,s=0;
printf("Enter n");
scanf("%d",&n);
{
while(n!=0)
{
r=n%10;
n=n/10;
s=s+r;
}
if(s+r==)
printf("%d", r);
}
}

