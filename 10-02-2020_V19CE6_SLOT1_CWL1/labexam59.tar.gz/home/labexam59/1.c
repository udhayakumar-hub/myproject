/*V19CE6H1
HEMALATHA N*/
#include<stdio.h>
int main()
{
int n,i=2,r=0,s,c=0;
  for(n=1000;n>0,n>=1;n--)
//for(n=1;n<=1000;n++)
  {
while(i<n)
{
if(n%i==0)
break;
i++;
}
if(i==n)
printf("%d\n",n);}
{
r=n%i;
n=n/10;
}
if(r==1)
printf("%d \n",r);
}



	
