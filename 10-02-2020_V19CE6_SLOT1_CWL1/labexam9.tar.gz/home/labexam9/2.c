//GNANA SEKAR V19CE6G3 QUESTION NO.2
#include<stdio.h>
int main()
{
int n,sum;
printf("Enter any number\n");
scanf("%d",&n);
while(n!=0)
{
sum=n%10;
n/=10;
}
