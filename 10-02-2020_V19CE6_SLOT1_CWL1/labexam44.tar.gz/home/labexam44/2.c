// name :ATHIVEL .A
// batch:V19CE6A1

//MUTIPLICATION TABLE 1TO 10

#include<stdio.h>
int main()
{
int i,j;
printf("multiplication table from 1 to 10\n");
for(i=1;i<=10;i++)
{
for(j=1;j<=10;j++)
{
printf("%d * %d= %d",i,j,i*j);
printf("\n");
}
}
}
