//Name=Nikunj solanki
//ID=V19CE6N5

#include<stdio.h>
int main()
{
	int n1,n2=1,r;

	for(n1=1000;n1>n2;n1--)
	
	{
		r=n1%2;
		n1=r/n1;
	
		{			
			if(n1==n2)
			printf("%d",n1);
		}
	printf("\n");
	}
}
