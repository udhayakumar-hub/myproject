//Name: R.Naveen, Batch ID: v19ce6n1
#include<stdio.h>
int main()
{
int n,i;
printf("Multiplication tables from 1 to 10\n");
for(n=1;n<=10;n++)
{
for(i=1;i<=10;i++)
{
printf("%d * %d =%d\n",n,i,n*i);
}
printf("\n");
}
}
