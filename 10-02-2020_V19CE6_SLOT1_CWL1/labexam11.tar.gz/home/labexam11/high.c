#include<stdio.h>
main()
{
int d;
printf("enter a digit\n");
scanf("%d",&d);
printf("%d",d);
}

