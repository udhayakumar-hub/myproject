//name:sathiya batch id:v19ce6s9
#include<stdio.h>
int main()
{
int n,i;

for(n=1;n<=10;n++)
{
{
for(i=1;i<=10;i++)
printf("%d*%d=%d\n",i,n,i*n);
}
printf("\n");
}
}
