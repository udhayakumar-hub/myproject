//U-ANUP V19CE6U1
#include<stdio.h>
int main()
{
int i,j;
printf("Multiplication Tables from 1 to 10\n");
for(i=1;i<=10;i++)
{for(j=1;j<=10;j++)
{
printf("%d * %d = %d\n",i,j,i*j);
}

}
}
