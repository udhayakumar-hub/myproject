//v19ce6v1-vasuki.R
#include<stdio.h>
int main()
{
int n,i=1;
printf("Enter the numbers\n");
scanf("%d",&n);
abc:
i++;
i<=n;
n=n*i;
goto
printf(" %d*%d=%d\n",n,i,n*i);
}




