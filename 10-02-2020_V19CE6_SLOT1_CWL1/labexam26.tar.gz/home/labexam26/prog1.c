#include<stdio.h>
int main()
{
int x,y,z;
printf("Enter the numbers \n") 
scanf("%d%d%d",&x,&y,&z);
{
if((x<z)&&(z<y))
printf("%d\n",second lowest no);
else if((x<y)&&(y>z))
printf("%d\n"second lowest no);
else if((z<x)&&(x>y))
printf("%d\n"second lowest no);
}

