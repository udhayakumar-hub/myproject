//v19ce6s1
//sukruthsoorya

#include<stdio.h>
int main()
{
int n,r,x,y,z;
printf("enter the number\n");
scanf("%d",&n);
while(n!=0)
{
big=n%10;
n=n/10;
big>(n%10)?(big:n%10)?big>(n/10)?(big2:n%10)

}
}



