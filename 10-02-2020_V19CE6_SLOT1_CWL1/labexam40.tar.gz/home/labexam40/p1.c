/*S.Ajeeth kumar
v19ce6s12*/
#include<stdio.h>
int main()
{
int a,r,sum,i,n;
scanf("%d",&n);
for(i=0;i<n;i++){
r=i%10;
sum=i/10;
}
printf("%d\n",r);
//i=sum%10;
/*if(i>r)
{
a=i;
}
else
{
a=r;
}*/
//printf("%d\n",r);
printf("%d\n",sum);
//printf("%d\n",i);
//printf("%d\n",a);
}

