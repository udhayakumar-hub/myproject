/*s.Ajeeth kumar
v19ce6s12*/
#include<stdio.h>
int main()
{
int n,i;
for(i=1;i<=10;i++)
{
for(n=1;n<=10;n++)
{
printf("%d*%d=%d\n",n,i,n*i);
}
printf("\n");
}
}
