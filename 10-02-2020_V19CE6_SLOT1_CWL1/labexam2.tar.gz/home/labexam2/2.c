//Divya Susan Jose
//v19ce6d4
#include<stdio.h>
int main()
{
int i,j,r,n;
for(n=1;n<=10;n++)
{
for(i=1;i<=10;i++)
{

r=n*i;
printf("%d * %d = %d\n",n,i,r);
}
printf("\n");
}
}
