/* rajkumar v19ce6r4 */

#include<stdio.h>
int main()
{
int i,a{}={15,10,8,9,7}
printf("enter the a value\n");
scanf("%d",a);
for(i<=a)
{
a=(a!n==0)
i++;
}
printf("first highest of digit");
printf("second highest of digit");
}

