#include<stdio.h>
main()
{
int n,s=0;
printf("Enter n");
scanf("%d",&n);
 t2=t=n;
 c=0;
  while(t2!=0)
    {  
     t2=t2/10;
     c++;
    }
  while(t1!=0)
    {
     r=n%10;
     t1/=10;
     s=n%10;
     t1/=10;
     t=-n%10;
    }



