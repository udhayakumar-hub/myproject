i//Name:j.skandakumar
//batch id v19ce6j3
#include<stdio.h>
int main()
{
int n,r,big;
printf("enter the number\n");
scanf("%d",&n);
for(n=0;n<0;n++)
{
big=n%10;
n=n/10;
r=n/10;
if(n==big)
{
printf(" big number\n");
}
}
}
