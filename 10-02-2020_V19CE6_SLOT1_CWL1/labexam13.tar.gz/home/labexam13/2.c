#include<stdio.h>
int main()
{
int i,j,n,sum;
printf("prime num\n");
}

