//(name:Dinesh kumar M and batch id:v19ce6d5)
#include<stdio.h>
int main()
{
int i,n,num;
printf("enter the number :\n");
scanf("%d");
for(i=0;i<=n;i++)
{
if(n%10==0)
printf("%d",&num);
}
}
