#include<stdio.h>
int main()
{
int low1,low2,n,a,t,i,c;
printf("Enter the Number\n");
scanf("%d",&n);
t=n;
for(i=0;t>0;i++)
{
a=t%10;
c++;

}}

