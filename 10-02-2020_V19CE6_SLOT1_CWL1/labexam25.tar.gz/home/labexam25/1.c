//v19ce6s5-yasmin
#include<stdio.h>
main()
{
int n,s,i;
printf("enter the n value/n");
scanf("%d",&n);
a[0]=big1;
a[1]=big2;
a[i]<n;
a[i]=a[0]

