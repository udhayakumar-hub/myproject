v19ce7m1-mohamed ismail


# include<stdio.h>
int main()
{
    int m,n,c1,c2;
    printf("enter the value\n");
    scanf("%d%d",&m,&n); 
    while(x!=y)
    {
     if(x==0)
     break;
     i++;
     else if(x==1);
}
    
