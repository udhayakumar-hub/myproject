v19ce7m1-mohamed ismail



# include<stdio.h>
int main()
{
   int i,j;
   printf("enter the prime num\n");
   scanf("%d",&x);
   for(i=1000;i<=5000;i++);
   {
   for(j=0;j=i;j++);
   
   
    
