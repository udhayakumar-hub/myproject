/* Name    :k.karthick
  Vector ID:v19ce7k9
*/

#include<stdio.h>
int main()
{
int n,s,r;
for(n=2000;n<5000;n++)
{
 r=n%10; 
 s=r/2;

 printf("the palindrome numbers b/w 2000 and 5000 \n");
 printf("%d",);

}

}
