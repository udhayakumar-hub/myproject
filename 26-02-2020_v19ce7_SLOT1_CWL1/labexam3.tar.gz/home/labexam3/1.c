/* Angel Reena C R
   batch ID:v19ce7a9 
   question: 1
*/

#include<stdio.h>
int main()
{
int n, pos;
printf("enter the number and bit position");
scanf("%d%d", &n,&pos);
n=n|(1<<pos);
switch(n):
{
case n:printf("set bit: %d",n);
	breeak;
default: break;
}


//set a bit= num|(1<<pos)



}
