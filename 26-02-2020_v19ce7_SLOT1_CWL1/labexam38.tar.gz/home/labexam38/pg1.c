#include<stdio.h>
int main()
{
int n,r,i rev=0;
printf("enter the n value \n");
scanf("%d,%d,%d ,n");
while
i=2000,i++;
printf(i<=5000,i++);

}


