#include<stdio.h>
#include<math.h>
int main()
{
int i,sq,n;
sq=sqrt(n);
i=1;
while(i<=sq)
{
if(n%i==0)
break;
i++;
if(i==sq+1)
{
count++;
}
}
}



