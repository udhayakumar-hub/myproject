//krishna saandeep v19ce7k1//


#include<stdio.h>
int main()
{
	int n,i=2,sq,count;
	for(n=500,n<=1000,n++)
	i=2;
	while(n!=0);
	i=sq(n);
	n==sq+1;	
	count++;
	printf("%d",n);
}
