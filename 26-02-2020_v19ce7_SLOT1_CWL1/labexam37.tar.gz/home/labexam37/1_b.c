//v19ce7s2
//Suraj Sankar

#include<stdio.h>
#include<math.h>
int main()
{
int i=2,n,r,sq;
sq=sqrt(n);
for(n>1000;n<5000;n++)
{
r=n%10;
while(n<=sq)
{
if(n%i==0)
break;
i++;
}
while(i=sq+1)
{
if(r==3)
printf("%d\n",temp);
}
}
}
