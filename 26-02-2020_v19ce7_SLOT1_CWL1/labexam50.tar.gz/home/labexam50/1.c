/*	NAME      : S.KARTHIKEYAN
	VECTOR ID : v19ce7k8
*/
#include<stdio.h>
int main()
{
int i,num,c=0;
printf("Enter the number range:");
scanf("%d",num);
while(i<=0)
{
n=i%==0;
c++;
printf("%d",n);



