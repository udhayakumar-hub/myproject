/* set a perticular bit
fadik k
v19ce7f1*/
#include<stdio.h>
int main()
{
int n,i,p,op;
for(i=31;i>0;i--){
printf("%d",n>>i&1);
printf("\n");
n=n|(1<<p)?puts("set"):puts("clear");
printf("%d",n);}
printf("enter the option\n");
scanf("%d",&op)
switch(op)
case1:"set a bit";
caseo:"clear a bit";
for(i=31;i>0;i--)
{
printf("%d",n>>i&i);
printf("\n");
}}



