//VIGNESHWAR V19CE7V1
#include<stdio.h>
#include<math.h>
int main()
{
int i,num=5000,sq,num1=1000;
while(i<num)
{
for(i=0;num1<=num;num--)
{
sq=sqrt(num);
i++;
}
}if(i==sq+1)
printf("%d",sq);
}
