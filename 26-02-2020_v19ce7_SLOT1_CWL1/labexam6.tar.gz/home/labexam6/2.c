name: R.Keerthiga
vector id: v19ce7r1
#include<stdio.h>
int main()
{
int 
printf("Enter the bit number\n");
scanf("%d",&)
}
