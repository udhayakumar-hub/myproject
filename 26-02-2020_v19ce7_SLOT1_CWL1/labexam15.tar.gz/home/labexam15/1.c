/*Name:N.PRAVEEN
Batch id:V19CE7P3*/
#include<stdio.h>
 main()
{
int pos,number;
printf("enter the pos of the bit to check");
scanf("%d & pos);
printf("enter the number value to set the bit\n");
scanf(" %d &number);
{
if(number=number|(1<<pos);
printf("the bit is set\n");
else("the bit is clear");
}

 

