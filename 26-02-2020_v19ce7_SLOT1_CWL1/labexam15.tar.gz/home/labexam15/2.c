/*Name:N.Praveen
Batchid:V19ce7p3*/
#include<stdio.h>
main()
{
int n,i=1,count=0;
printf("enter the value of n\n");
scanf("%d &n");
for(i<n,n%i,i=0)
{
count++;
i++;
{if(count==0)
printf("prime number");




