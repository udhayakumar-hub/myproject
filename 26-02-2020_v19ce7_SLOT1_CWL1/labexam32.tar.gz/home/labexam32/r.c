#include<stdio.h>
int  main()
{
int num,pos,op=1 ;
printf("enter the num pos value\n");
scanf("%d%d"&num,&pos);
switch(op)
{
case 1:num&~(num<<os);
case 2:printf("enter the clear\n");
case 3:printf("enter the set

if(num~(num<<pos);
}

}

