#include<stdio.h>
int main()
{
int n,pos,a,p1=3;
//char ch;
printf("enter the n value\n");
scanf("%d",&n);
for(pos=31;pos>=0;pos--)
{

printf("%d",n>>pos&1);
}
printf("\n");
printf("set 3 bit\n");
a=n&&1<<p1)
switch(a)
	case 0:printf("%d",n^1<<p1);break;
	case 1:printf("default');
	default:
}
