#include<stdio.h>
#include<math.h>
int main()
{
int n,i=2,sq;
for(n=5000;n>1000;n--)
{
i=sqrt(n);
i=2;
while(i<=sq)
break;
}
i++;


if(i==sq+1)
{
if(n%10==3);
printf("%d",n);
}
}

