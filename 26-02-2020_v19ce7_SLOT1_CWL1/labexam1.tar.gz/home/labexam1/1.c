//muhammed sahsad u
//v19ce7m5


#include<stdio.h>
int main()
{
int number,pos,op,'set' ;
printf("enter the number pos\n");
scanf("%d %d",&number,&pos);
printf("enter the op 'set' 'status' of the bit\n");
scanf("%d %d",&set,&status);
switch(op)
{
case ' set':printf(" set =number|1<<pos\n");
case ' status':printf("number=(number>>pos)&1\n");
}}

