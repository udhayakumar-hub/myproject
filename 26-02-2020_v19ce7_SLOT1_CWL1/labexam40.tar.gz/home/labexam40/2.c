/*susendra kumar
  v19c37s5*/
#include<stdio.h>
int main()
{
int n,i=2,sq,,numcount=0;
printf("enter the number\n");
scanf("%d",&n);
i=2;
sq = sqrt(n)
for(i=2;i<=100;i++)
{
while(i%2==0)
count++;
i++;
break;
}
if(count==2)
printf("%d",num);
}


