/*  susendra kumar
    v19c37s5*/
#include<stdio.h>
int main()
{
int num,pos,num1;
printf("enter a num,pos\n");
scanf("%d%d",&num,&pos);
switch()
{
case1:num==num
if((num>>pos)&&1)
{
printf("bit is clear\n");
else
if((num>>pos)^1))
{
printf("the complement of a bit\n");
}
}
}
}
