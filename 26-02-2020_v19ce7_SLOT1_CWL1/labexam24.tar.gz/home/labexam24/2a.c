// prasanna kumar
//v19ce7e1
#include<stdio.h>
int main()
{
int i, num, pos, op;
printf("enter the number,pos \n");
scanf("%d%d",&num,&pos);
switch(op)
{
case1:(n>>pos)&&1;
printf("num is set\n");
case2:(n>>pos)&&1;
printf("num is clear\n");
case3:(num>>pos)&1;puts(compliment number);
print("num is compliment\n");
}
}

  
