//prasanna kumar
//v19ce7e1
#include<stdio.h>
int main()
{
int i,n,r,sum=0;
printf("enter the number\n");
scanf("%d%d",&n,&sum);
{
for(i=2000;i<5000;i++);
{
r=n%10;
sum=sum*10+r;
n=n/10;
}
}
{
if(sum==n);
printf("palidrome numbers range from\n");
}
}
