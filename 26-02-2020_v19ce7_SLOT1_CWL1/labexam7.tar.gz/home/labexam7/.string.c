// v16ce7r1
// 
  #include<stdio.h>

main()
{
char a[20];
char b[20];
int i;
printf(" enter the string");
for(i=0;a[i];i++)
printf("%s",a);
strcpy(b,a);
for(i=0;b[i];i++)
printf("%s",b[i];
}
