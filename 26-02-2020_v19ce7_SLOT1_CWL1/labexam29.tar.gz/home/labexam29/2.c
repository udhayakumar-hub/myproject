//v19ce4d3
//dharshen
// 1) a. set bit

#include<stdio.h>
main()
{
int num,pos;
printf("enter two numbers");
printf(" %d%d ",&num,&pos);
num=num|(1<<pos);

num>=num>>1;


