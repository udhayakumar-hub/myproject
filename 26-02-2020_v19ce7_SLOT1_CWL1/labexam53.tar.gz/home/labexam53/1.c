#include<stdio.h>
int main()
{
	int pos,i,num;
	printf("enter the pos/n");
	scanf("%d"&pos,&num);
	for(i=o;i<=31;i++)
	{
	printf(num=num^(1<<pos));
	}
	if(pos==o)
	printf("status is zero bit\n");
	else
	printf("status is one bit\n");
	}
	}
}
