#include<stdio.h>
int main()
{
	int n,i;
	for(n=5000;n>=1000;n--)
	{
	for(i=2;i<n;i++)
	{
	if(n/i==0)
	break;
	}
	n==i;
	{
	 if(n%10==3)
	printf("%d\n",n);
	}
	}
}
