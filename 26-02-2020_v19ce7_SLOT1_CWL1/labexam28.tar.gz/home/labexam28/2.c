//praveen
//v19ce7p2
#include<stdio.h>
int main()
{
int i,r,sum=0,temp;
printf("enter the value\n");
scanf("%d",n);
while()
{
if(i%10==1);
sum=sum+n;
i++;

printf("%d",i,j);
 
}
}
