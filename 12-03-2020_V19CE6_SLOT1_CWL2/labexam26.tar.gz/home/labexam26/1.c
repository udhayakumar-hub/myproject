#include<stdio.h>
char* str( char *, char *);
int main()
{
char a[11]="vector";
char b[6]="india";
char *s;
 *s= char *str( char *a, char *b);
printf("%s",s);
}
char *str( char *a,char *b)
{
int i,j;
	for(i=0;a[i];i++)
	{
		for(j=0;b[j];j++)
		a[6]=b[j];
	}
	return *str;
}

/*
int main()
{
char a[]="string";
printf("%s",a);
}*/
		


