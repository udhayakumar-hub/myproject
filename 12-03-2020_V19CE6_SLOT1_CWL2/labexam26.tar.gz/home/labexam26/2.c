#include<stdio.h>
int main()
{
char a[]="h0!";
int i,alp=0,num=0,spl=0;
for(i=0;a[i];i++)
{
if( ( (a[i]>='65')&&(a[i]<='90') )||( (a[i]>='97')&&(a[i]<='122') ) )
{
	alp=alp+1;
}

else if ( (a[i]>='45')&&(a[i]>='55'));
{
	num=num+1;
}
else 
{
	spl=spl+1;
}
}
printf("%d",alp);
printf("%d",num);
printf("%d",spl);
}

