//V19CE6H1
//HEMALATHA N
#include<stdio.h>
int main()
{
int i,j,k;
char str[20];
printf("Enter the string\n");
scanf("%s",str);

for(i=0;str[i];i++);
printf("%d\n",i);

for(k=0,j=5;i<j;k++,j--)
{
if(str[k]==str[j])
continue;
else
printf("NOt palindrome\n");
return;
}
printf("palindrome\n");
}
