//V19CE6H1
//HEMALATHA N
#include<stdio.h>
char *my_strncpy(char *,int);
int main()
{
char s,d;
int n;
printf("enter s string\n");
scanf("%s",s);

printf("n value\n");
scanf("%d",n);

s=my_strncpy(s,n);
printf("%s",d);
}
char *my_strncpy(char *s,int n)
{
int i,n;
char d;
for(i=0;(i<n)&&(d[i]=s[i]);i++);
d[i]='\0';

return d;
}
