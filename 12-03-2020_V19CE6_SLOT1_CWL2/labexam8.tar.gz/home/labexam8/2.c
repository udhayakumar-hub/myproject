//Name:N.Vasanth kumar
//ID:v19ce6v2


#include<stdio.h>
#include<string.h>
int main()
{
char s[50];
int i,j,n,c1=0,c2=0,c3=-1;
printf("enter the string:");
scanf("%[^\n]",s);
for(i=0;s[i];i++);
n=i;
for(j=0;j<=n;j++)
{
if(s[j]>='a'&& s[j]<='z')
++c1;
else if(s[j]>='0'&& s[j]<='9')
++c2;
else 
c3++;
}
printf("no of alphabets=%d\n",c1);
printf("no of integers=%d\n",c2);
printf("no of special character=%d\n",c3);
}
