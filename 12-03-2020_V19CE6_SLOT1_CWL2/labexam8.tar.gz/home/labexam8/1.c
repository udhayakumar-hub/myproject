//name:N.Vasanth kumar
//ID:v19ce6v2

#include<stdio.h>
char* cat(char*,char*);
int main()
{
char s1[20],s2[20];
printf("enter the source1 string:\n");
scanf("%s",s1);
printf("enter the source2 string:\n");
scanf("%s",s2);
char *p=cat(s1,s2);
printf("destination string is %s\n",p);
}
char* cat(char* s1,char* s2)
{
int i,j;
for(i=0;s1[i];i++);
for(j=0;s2[j];i++,j++)
s1[i]=s2[j];
s1[i]='\0';
return s1;
}
