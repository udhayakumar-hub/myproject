//Jegan Bruno
// V19CE6J1
// Userm defined strcat function
char *my_strcat(char *p,char *q);
#include<stdio.h>
int main()
{
char s[20],d[20];
printf("enter the source string\n");
scanf("%s",s);
printf("enter the destination string\n");
scanf("%s",d);

char *p=my_strcat(s,d);
printf("%s\n",d);
printf("%s",p);
printf("\n");
}
char *my_strcat(char *p,char *q)
{
int i,j;
for(i=0;q[i];i++);
for(j=0;p[j];j++,i++)
q[i]=p[j];
q[i]='\0';
//printf("%s",p[i]);
return q;
}
