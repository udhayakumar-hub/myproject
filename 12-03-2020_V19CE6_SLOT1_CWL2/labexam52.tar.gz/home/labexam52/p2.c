//Jegan BRuno
//V19CE6J1
#include<stdio.h>
int main()
{
char a[10]={'a','b',3,'b','c',6,'E','$','$'};
int i,c=0,d=0,e=0;

for(i=0;i<10;i++)
printf("%c",a[i]);

printf("\n");
for(i=0;a[i];i++)
{
	if(((a[i]>='A')&&(a[i]<='Z'))||((a[i]>='a')&&(a[i]<='z')))
	c++;
	else if((a[i]>=0)&&(a[i]<=9))
	d++;
	else
	e++;
}
printf("No Of alphabets =%d\n",c);
printf("No Of numerics =%d\n",d);
printf("No Of symboles =%d\n",e);
}
