/*Althaf Mohammed V A
  V19CE6A6
*/
#include<stdio.h>
main()
{
char a[20],i,j;
printf("Enter the string\n");
scanf("%s",a);
for(j=0;a[j];j++);
for(i=0,j=j-1;i<j;i++,j--)
 {
  if(a[i]!=a[j])
  break;
 }
if(i<j)
printf("not pallindrome\n");
else
printf("pallindrome\n");
}


