#include<stdio.h>
#include<string.h>
main()
{
char s[20],d[20];
int n;
printf("Enter string\n");
scanf("%s",s);
printf("Enter n\n");
scanf("%d",&n);
char*p=strncpy(d,s,n);
printf("d=%s",d);
}
