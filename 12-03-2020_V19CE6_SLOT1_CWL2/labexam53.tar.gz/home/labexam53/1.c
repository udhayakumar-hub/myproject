/*Althaf Mohammed V A
V19CE6A6
*/
#include<stdio.h>
char* mystrncpy(char*p,char*q,int n);
main()
{
char s[20],d[20];
int n;
printf("Enter the source string\n");
scanf("%s",s);
printf("Enter n\n");
scanf("%d",&n);
char*ptr=mystrncpy(d,s,n);
d[n]='\0';
printf("d=%s\n",d);
}
char* mystrncpy(char*p,char*q,int n)
{
int i;
for(i=0;i<n&&q[i];i++)
p[i]=q[i];
for(;i<n;i++)
p[i]='\0';
return p;
}
