#include<stdio.h>
int main()
{
char a[20]="v19ce6@b1";
int al=0,nc=0,sp=0,l,i;
for (l=0;a[l];l++);

for(i=0;a[i];i++){
if ((a[i]>='A')&&(a[i]<='Z')||((a[i]>='a')&&(a[i]<='z')))
{
    al++;
}
else if ((a[i]>='0')&&(a[i]<='9'))
      nc++;

else
     sp++;
}
printf("alphabets=%d\n",al);
printf("numeric digits=%d\n",nc);
printf("special characters=%d\n",sp);
}
