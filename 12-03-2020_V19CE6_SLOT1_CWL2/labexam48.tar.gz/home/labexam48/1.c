/*Balamurugan E
v19ce6b1*/

#include<stdio.h>
#include<string.h>
char* my_strcat(char*,char*);
int main()
{
char s[20]="vector",d[20]="india";

char *p=my_strcat(d,s);
printf("%s\n",p);
}
char* my_strcat(char *p,char*q)
{
int i,j;
for(i=0;q[i];i++)

for(j=0;p[j];j++,i++)
q[i]=p[i];
q[i]='\0';
return p;
}






