//thambidurai
//v19ce6u2
#include<stdio.h>
int main()
{
char a[10];
int i,j,l;
printf("enter the string\n");
scanf("%s",a);
for(i=0;a[i];i++);
l=i;
for(i=0,j=l-1;i<j;i++,j--)
{
if(a[i]!=a[j])
break;
int temp=a[i];
a[i]=a[j];
a[j]=temp;
}
if(i>=j)
printf("palindrome\n");
else
printf("not palindrome\n");
}


