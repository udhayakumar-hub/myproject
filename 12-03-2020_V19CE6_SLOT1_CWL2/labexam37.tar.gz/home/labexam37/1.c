//thambidurai
//v19ce6u2
#include<stdio.h>
char*strn(char*,char*,int);
int main()
{
char a[10],b[10];
int n;
printf("enter source string\n");
scanf("%s",a);
printf("enter n value\n");
scanf("%d",&n);
char*p=strn(a,b,n);
printf("destination string is %s\n",p);
}
char*strn(char*a,char*b,int n)
{
int i;
for(i=0;i<n;i++)
b[i]=a[i];
b[i]='\0';
return b;
}

