//BIGHOSH KRISHNA R
//V19CE5B1

#include<stdio.h>
#include<string.h>
char* my_strcpy(char*,char*,int);
int main()
{
	int n,i,j;
	char s[50],d[50];

printf("enter the string\n");
scanf("%s",s);

printf("enter the no. of characters to copy\n");
scanf("%d",&n);

char*p=(char*)my_strcpy(d,s,n);


printf("%s\n",d);

}
char* my_strcpy(char*p,char*q,int n)
{
	int i;
	for(i=0;((q[i])&&(i<n));i++)	
	p[i]=q[i];
	p[i]='\0';
}
