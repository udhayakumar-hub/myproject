#include<stdio.h>
int main()
{	
	int i,j,k;
	char s[50];
	printf("enter the string\n");
	scanf("%s",s);
	
	for(i=0;s[i];i++);
	
	for(j=0,k=i-1;s[j];j++,k--)
	{
		if(s[j]!=s[k])
		break;
	continue;
	}
	
	if(s[j]=='\0')
		printf("pal\n");
	else
		printf("not pal\n");
	
	
}
