//v19ce6r5
// Arunpandi R

#include<stdio.h>

char *my_strncpy(char *,char *,int );

void main()
{
	char a[100],b[100];
	char *p;
	int n;
	puts("enter the source string");
	scanf("%[^\n]s",a);
	
	puts("enter the number of bytes want to copy");
	scanf("%d",&n);
	
	p=my_strncpy(a,b,n);
	
	printf("the string in destination is %s\n",b);
	printf("the string in return address is %s\n",p);
}

char *my_strncpy(char *p,char *q,int n)
{
	int i;
	for(i=0;(i<n) && p[i];i++)
	 q[i]=p[i];
	
	q[i]='\0';
	return q;
}
