//v19ce6r5
// Arunpandi R

#include<stdio.h>
#include<string.h>
void main()
{
char a[100],b[100];
int i,j;
puts("enter the string");
scanf("%[^\n]s",a);
for(i=0,j=strlen(a)-1;i<j;i++,j--)
if(a[i]!=a[j]) break;

if(i>=j) puts("the string is palindrome");
else puts("not palindrome");

}
