//MOULEESWARAN S
//V19CE6M2


#include<stdio.h>
main()
{
int i,al=0,d=0,s=0;
char a[20];
printf("Enter the string\n");
scanf("%s",a);
for(i=0;a[i];i++)
{
if(a[i]>='a'&&a[i]<='z')
al++;
else if(a[i]>='A'&&a[i]<='Z')
al++;
else if(a[i]>='0'&&a[i]<='9')
d++;
else
s++;
}
printf("In the given string\n  %d Alphabet(s)\n  %d Numeric character(s)\n  %d Special character(s)\n",al,d,s);
return 0;
}

