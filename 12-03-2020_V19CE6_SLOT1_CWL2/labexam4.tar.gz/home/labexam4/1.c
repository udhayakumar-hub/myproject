//MOULEESWARAN S
//V19CE6M2



#include<stdio.h>
char *my_strcat(char *d,char *s)
{
int i,j,n1,n2;
for(i=0;d[i];i++);
n1=i;
for(i=0;s[i];i++);
n2=i;
for(i=0,j=n1;s[i];i++)
{
d[n1]=s[i];
n1++;
}
d[(n1+n2)-1]='\0';
return d;
}
main()
{
char s[200],d[200];
printf("Enter the source string\n");
scanf("%s",s);
printf("Enter the destination string\n");
scanf("%s",d);
char *p=my_strcat(d,s);
printf("The result is: %s \n",p);
return 0;
}


