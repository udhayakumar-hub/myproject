//V19CE6U1 U-ANUP
#include<stdio.h>
char*my_strncpy(char*,char*,int);
int main()
{
char s[20],d[20],*p;
int n;
printf("Enter source string\n");
scanf("%s",s);
printf("Enter n value to copy from source to destination string\n");
scanf("%d",&n);
p=my_strncpy(s,d,n);
printf("After copy destination string is,\n");
printf("%s\n",p);
}
char *my_strncpy(char *s,char *d,int n)
{
int i,l;
for(l=0;s[l];l++);
for(i=0;i<l;i++)
{
if(i<n)
d[i]=s[i];
else
d[i]='\0';
}
if(n>=i)
d[i]='\0';
return d;
}
