//V19CE6U1   U-ANUP
#include<stdio.h>
int main()
{
char a[20];
int i,j,l,f=0;
printf("Enter the string\n");
scanf("%s",a);
for(l=0;a[l];l++);
for(i=0,j=l-1;i<j;i++,j--)
{
if(a[i]!=a[j])
{f=1;
 break;
}
}
if(f==1)
printf("Given string is not a palindrome\n");
else
printf("Given string is a palindrome\n");
}
