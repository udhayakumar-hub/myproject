#include<stdio.h>
int main()                                   //K.Dhinesh Kumar   V19ce6d2
{
char a[10];
int i,j,l;
printf("Enter the string:\n");
scanf("%s",a);
printf("Given string:%s\n",a);
for(i=0;a[i];i++);
l=i;
for(i=0,j=l-1;i<j;i++,j--)
{
if(a[i]!=a[j])
break;
}
if(i==j||i>j)
printf("The given string is %s palindrome\n",a);
else
printf("The given string is %s not palindrome\n",a);
}

