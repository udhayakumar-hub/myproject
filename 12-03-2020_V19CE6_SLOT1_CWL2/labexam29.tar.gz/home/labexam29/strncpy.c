#include<stdio.h>
char * my_strncpy(char *d,char *s,int n);
int main()                                       //K.Dhinesh kumar V19ce6d2
{
char s[20],d[20]={0};
int n;
printf("Enter the source string:\n");
scanf("%s",s);
printf("Source string:%s\n",s);
printf("Enter the nvalue:\n");
scanf("%d",&n);
char *p=my_strncpy(d,s,n);
printf("Resultant string is:\n");
printf("%s\n",p);
}
char *my_strncpy(char *d,char *s,int n)
{
int i;
for(i=0;i<n;i++)
d[i]=s[i];
return d;
}

