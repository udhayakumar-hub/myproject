//v19ce6s3
//surya

#include<stdio.h>
char* my_strcat(char *,char *);
int main()
{
char s1[20];
char s2[20];

printf("Enter the string1:\n");
scanf("%s",s1);
printf("Enter the string2:\n");
scanf("%s",s2);

char *p=my_strcat(s1,s2);
printf("After strcat:\n%s\n",s1);
}

char *my_strcat(char* s1,char* s2)
{
int i,j;
for(i=0;s1[i];i++);

for(j=0;s2[j];j++,i++)
{
s1[i]=s2[j];
}
s1[i]='\0';
return s1;
}
