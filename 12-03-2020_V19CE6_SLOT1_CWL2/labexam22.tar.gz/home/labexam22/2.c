//v19ce6s3
//surya



#include<stdio.h>
int main()
{
int i,c=0,n=0,s=0;

char a[20];
printf("Enter the string:\n");
scanf("%s",a);

for(i=0;a[i];i++)
{
if(((a[i]>='a')&&(a[i]<='z'))||(((a[i]>='A')&&(a[i]<='Z'))))
{ 
c++;
}
else if((a[i]>='0')&&(a[i]<='9'))
{
n++;
}
else s++;
}
printf("No of characters: %d\nNo of digits: %d\nNo of special characters:%d\n",c,n,s);
}
