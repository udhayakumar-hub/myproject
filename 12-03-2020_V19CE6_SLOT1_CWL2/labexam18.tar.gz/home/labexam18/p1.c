#include<stdio.h>
void my_strcat( str,str)
int main()
{
int i,j,n;
char s1[20],s2[10];
printf("enter the s1 string\n");
scanf("%s",s1);
printf("enter the s2 string\n");
scanf("%s",s2);
n=my_strcat(s1,s2);
printf(" %s",n);
}
void my_strcat(str s1,str s2)
{
for(i=0;a[i]<='0';i++)
{ for(j=l-1;a[j];j++)
  {
     s1[i]='0';
s1[i]=s2[j];
}
}


