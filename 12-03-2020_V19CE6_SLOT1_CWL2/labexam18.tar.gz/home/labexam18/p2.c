#include<stdio.h>//GAYATHRI v19ce6g2
int main()
{
int i,j,count=0;
char a[10];
printf("enter the string\n");
scanf(" %s",a);
for(i=0;a[i];i++)
{
if((a[i]>='A')&&(a[i]>='z')||(a[i]>='a')&&(a[i]<='z'))
{
count++;
printf("no of char in string: %d\n",count);
}
else if((a[i]>='0')&&(a[i]<='9')
{count++;
printf("no of digits in string: %d\n",count);
}
else
printf("no of spl char in string: %d\n",a[i]);
} 
}


