/* NAME : M.Balaji
    ID  : v19ce6b2 */

#include<stdio.h>
int main()
{
int i,j,ele;
char a[20];
printf("enter the string\n");
scanf("%s",a);
ele=sizeof a/sizeof a[0];
for(i=0,j=ele-1;i<j;i++,j--)
{
if(a[i]==a[j])
continue;
else
break;
}
if((i<j)
printf("given string is palindrome\n");
else
printf("given string is not a palindrome\n");
}

