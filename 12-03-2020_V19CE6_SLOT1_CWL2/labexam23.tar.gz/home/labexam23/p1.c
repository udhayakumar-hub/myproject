/* Name :M.Balaji
   id   :v19ce6b2*/
#include<stdio.h>
char *my_strncpy(char *,char *,int n);
int main()
{
char s[20],d[20];
int n;
printf("Enter the source string\n");
scanf("%s",s);
printf("enter the n value to copy\n");
scanf("%d",&n);
d = my_strncpy(d,s,n);
printf("the copied string is\n");
scanf("d = %s".d);
}
char *my_stryncpy(char*d, char*s, int n)
{
int i;
for(i=0;i<n;i++)
d[i]=s[i];

d[i]='\0';
return d;
}
