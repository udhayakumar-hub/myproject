//Suriya Vignesh.P(v19ce6s2)
#include<stdio.h>
void mystrcpy(char*,char*);
int main()
{
char str1[10]="Race";
char str2[4]="Bike";

printf("%s\n",str1);
printf("%s\n",str2);

mystrcpy(str1,str2);

}
void mystrcpy(char* s1,char* s2)
{
int a,b,l1,l2,i,j;

for(a=0;s1[a];a++)
{
l1=a;
}
printf("l1=%d\n",l1);

for(b=0;s2[b];b++)
{
l2=b;
}
printf("l2=%d\n",l2);

for(i=0;i<10;i++)
{
if(i==NULL);
i++;
for(j=0;j<=l2;j++)
s1[i]=s2[j];
}
printf("%s\n",s1);
}



