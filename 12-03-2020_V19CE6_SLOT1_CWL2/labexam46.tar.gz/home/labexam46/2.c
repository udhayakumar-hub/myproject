//GNANA SEKAR M
//V19CE6G3
//QUESTION NO. 2
#include<stdio.h>
#include<string.h>
int main()
{
char s[20];
int i,c1=0,c2=0,c3=0;
printf("Enter the string\n");
scanf("%s",s);
int len=strlen(s);
printf("%d",len);
for(i=0;i<len;i++)
{
if((65>=s[i]<=90)||(97>=s[i]<=122))
c1++;
}
for(i=0;i<len;i++)
{
if((45>=s[i]<=54))
c2++;
}
c3=len-(c1+c2);

printf("alphabet=%d,numbers=%d,special character=%d\n",c1,c2,c3);
}
