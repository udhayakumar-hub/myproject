//GNANA SEKAR M
//V19CE6G3
#include<stdio.h>
#include<string.h>
void my_strcat(char* s,char* d,int l1,int l2);
int main()
{
char s[10],d[10];
printf("Enter the source\n");
scanf("%s",s);
int l1=strlen(s);
printf("Enter the destination\n");
scanf("%s",d);
int l2=strlen(d);
my_strcat(s,d,l1,l2);
}
void my_strcat(char* s,char* d,int l1,int l2)
{
int i,j;
for(i=l1+1,j=0;j<=l2;i++,j++)
{
d[i]=s[j];
}
printf("%s",s);
}
