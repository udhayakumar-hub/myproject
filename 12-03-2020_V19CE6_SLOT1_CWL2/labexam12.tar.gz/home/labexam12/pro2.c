//Name: Ilangovan Bhanupriya   Id: v19ce6i1

#include<stdio.h>
#include<string.h>
int main()
{
  char str[50];
  int i,l,a=0,num=0,spcl=0;
  printf("Enter the string\n");
  gets(str);
  printf("string elements count:\n");
  l=strlen(str);
  for(i=0;i<l;i++)
  {
    if((str[i]>='A'&& str[i]<='Z') || (str[i]>='a'&&str[i]<='z'))
     a++;
    else if(str[i]>='0' && str[i]<='9')
     num++;
    else
     spcl++;
  }
  printf("Alphabets:  %d \nNumeric:  %d  \nSpecial Symbols:  %d\n",a,num,spcl);
 
   

}



