// Name: Ilangovan Bhanupriya    Id: v19ce6i1

#include<stdio.h>
#include<string.h>
char *str_cat(int,int,char *s,char *p);
int main()
{
  char s[20],d[50];
  int sl,dl;
  printf("Enter the source string\n");
  scanf("%s",s);
  printf("Enter the destination string\n");
  scanf("%s",d);
  sl=strlen(s);
  dl=strlen(d);
    
  char *p=str_cat(sl,dl,s,d);
  printf("%s\n",p);

}

char *str_cat(int sl,int dl,char *s,char *p)
{
   int i,l;
   l=sl+dl;
   for(i=dl;i<l;i++)
   p[i]=s[i-dl];
   p[l]='\0';
   return p;
}

   
