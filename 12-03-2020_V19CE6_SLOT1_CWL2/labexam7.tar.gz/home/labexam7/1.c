//Date:12-03-2020
//Athul P  V19CE6A2
#include<stdio.h>                         //including header file for standard input output operations
char * my_strncpy(char *p,char *q,int n); //function declaration
int main()                                //main function
{
char s[20],d[20];                         //two character array memories for source and destination
int n;                                    //for how many characters to be copied
printf("enter source string\n");          //inputting source string
scanf("%[^\n]",s);                        //reading of source string
printf("enter n value\n");                //inputting n value
scanf("%d",&n);                           //reading of n value
char *p=my_strncpy(d,s,n);                //user defined strncpy function call which returns base address of destination storing into character pointer
d[n]='\0';                                //putting null character for termination purpose
printf("p=%s\n",p);                       //through pointer printing the destination string
}
char * my_strncpy(char *p,char *q,int n)  //function definition
{
int i;
for(i=0;(i<n&&q[i]);i++)
p[i]=q[i];                               //upto given n value each character of source copied into same locations of destination through pointers
for(;i<n;i++)                            //if n value less than source length remaining characters are filled up with null bytes
p[i]='\0';
return p;                                //returning the destination base address
}
