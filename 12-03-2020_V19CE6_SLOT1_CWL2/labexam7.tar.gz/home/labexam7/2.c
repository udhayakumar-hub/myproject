//Date:12-03-2020
//Athul P  V19CE6A2
#include<stdio.h>              //including headerfile for standard input ouyput operations
#include<string.h>             //for predefined strlen operations
int main()                     //main function
{
char s[20];                    //for storing string input
int i,j,l;                     
printf("enter the string\n");  //inputting string
scanf("%[^\n]",s);             //reading string
l=strlen(s);                   //calculatting length of string
for(i=0,j=l-1;i<j;i++,j--)     //comparing first and last elements .one index points to 0 th and another to last(l-1) th positions.this process continues
{
if( s[i]!=s[j] )               //if they are not equal means stop that operations
break;
}
if(i<j)                       //if the loop is breaked within the true condition means all characters are not compared or equal.so not palindrome
printf("not palindrome\n");
else
printf("palindrome\n");
}
