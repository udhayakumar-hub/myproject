//Batch id:v19ce6p1,Name:N.Prasanna Venketeshan//
#include<stdio.h>
char * my_strcat(char *,char*);
int main()
{
int s[20],d[20],n1,n2;char * d1;
printf("Enter the source string\n");
n1=sizeof s/sizeof s[0];
scanf("%s",s);
printf("Enter the destination string\n");
scanf("%s",d);
n2=sizeof d/sizeof d[0];
d1=my_strcat(d,s);
printf("%s",d1);
}
char * my_strcat(char * d1,char * s1)
{
int dl,sl,i,j;
for(sl=0;s1[sl];sl++);
for(dl=0;d1[dl];dl++);
int free_bytes=20-dl+1;
if(free_bytes<sl)
printf("Insufficient memory\n");
else
for(i=dl,j=0;d1[i]=s1[j];i++,j++);
return d1;
}
 
