//Batch id:v19ce6p1,Name:N.Prasanna Venketeshan//
#include<stdio.h>
int main()
{
int n,al,i,alpha=0,digit=0,special=0;
char a[20];
printf("Enter the string\n");
scanf(" %s",a);
n=sizeof a/sizeof a[0];
for(al=0;a[al];al++);
for(i=0;i<al;i++)
{
if(((a[i]>='a')&&(a[i]<='z'))||((a[i]>='A')&&(a[i]<='Z')))
alpha++;
else if((a[i]>='0')&&(a[i]<='9'))
digit++;
else
special++;
}
printf("Alphabet count=%d Digit count=%d Special character count=%d",alpha,digit,special);
}




