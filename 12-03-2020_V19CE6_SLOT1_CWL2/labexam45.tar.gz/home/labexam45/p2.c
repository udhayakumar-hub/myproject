//prem.s
//v19ce6p2
#include<stdio.h>
main()
{
char s[20];
int i,j,l;
printf("enter the string\n");
scanf("%[^\n]",s);
for(l=0;s[l];l++);
for(i=0,j=l-1;i<j;i++,j--)
{
if(s[i]!=s[j])
break;
}
if((j<i)||(j==i))
printf("it is a palindrome string\n");
else
printf("not a palindrome string\n");
}

