//prem.s
//v19ce6p2



#include<stdio.h>
void my_strncpy(char *,char *,int );
main()
{
char s[20],d[20];
int n;
printf("enter the source string\n");
scanf("%[^\n]",s);
printf("enter the n value\n");
scanf("%d",&n);
my_strncpy(d,s,n);
printf("destination string\n");
printf("%s\n",d);
}
void my_strncpy(char *p,char *q,int n)
{
int i;
for(i=0;i<n;i++)
{
p[i]=q[i];
}
p[i]='\0';
}
