v19ce6g4
#include<stdio.h>
int main()
{
	int a,i,j,b=0,c=0,d=0;
	printf("Enter the string\n");
	scanf("%s",&a);
	for(i=0;a[i];i++)
	for(i=0;i<j;i++)
	{
	if(((a[i]>='A')&&(a[i]<='Z')) ||
           ((a[i]>='0')&&(a[i]<='9')))
	b++;
	else if((a[i]>='0')&&(a[i]<='9'))
	c++;
	else
        d++;
	}
	printf("The number of alphabets are: %d",b);
	printf("The number of digits are: %d",c);
	printf("The number of special characters are: %d",d);	

}
