v19ce6g4
#include<stdio.h>
char**my_strcat(char*,char*)
int main()
{
	char d[20],s[20];
	printf("Enter the source string:\n");
	scanf("%s",&s);
	printf("Enter the destination string;\n");
	scanf("%s",&d);
	d=my_strcat(d,s);
	printf("The concatinated string is :");
	scanf("%s",&d);
}
char* my_strccat(char*d,char*s)
{
	int i,free_bytes;
	for(dl=0;dl[i];dl++);
	for(sl=0;sl[i];sl++);
	free_bytes=sizeof d - sizeof dl+1;
	if(free_bytes<sl)
	printf("Insufficient memory\n");
	else if(free_bytes>sl)
	for(i=0;d[i];d++)
	{
	for(j=0;s[j];j++)
	d[i]=s[j];
	}
	d[i]='\0';
	return d;

}
