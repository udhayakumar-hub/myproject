#include<stdio.h>
int main()
{
	int str_n,i,alpha=0,number=0,symb=0;
	char str[20]={};
	printf("Enter the string...\n");
	scanf("%s",str);
	//for(str_n=0;str[str_n];str_n++);
	for(i=0;str[i];i++)
	{
		if((str[i]>='A')&&(str[i]<='Z'))
		alpha++;
		else if((str[i]>='a')&&(str[i]<='z'))
		alpha++;
		else if((str[i]>='0')&&(str[i]<'9'))
		number++;
		else
		symb++;
	}
	printf("Alphabets = %d Numbers = %d symbols = %d\n",alpha,number,symb);
}
