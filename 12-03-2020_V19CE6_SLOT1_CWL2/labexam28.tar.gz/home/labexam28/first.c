/*Author : sivahari
  ID     : v19ce6s6 */
#include<stdio.h>
char *my_strcat(char*,char*);
int main()
{
	char dest[30]={},src[30]={},*str_ptr=NULL;
	printf("Enter the source string\n");
	scanf(" %[^\n]s",src);
	printf("Enter the Destination string\n");
	scanf(" %[^\n]s",dest);
	str_ptr = my_strcat(dest,src);
	printf("%s\n",str_ptr);
}

char *my_strcat(char *dest,char *src)
{
	int src_n,des_n,i;
	for(des_n=0;dest[des_n];des_n++);
	for(i=0;dest[des_n++]=src[i];i++);
	return dest;
}
