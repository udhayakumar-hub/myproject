//Z. SHATHIK HUSSAIN V19CE6S10

#include<stdio.h>
void strcat(char,char);
int main()
{
 char s1[20],s2[20];
 printf("Enter string1 s1=");
 scanf("%s",s1);
 printf("\nEnter string s2=");
 scanf("%s",s2);
 (char *) res = strcat(s1,s2); 
 printf("\nThe result is=%s",s1);
}
void strcat((char*) l[20],(char*) k[20])
{
 int n1,n2,i,j,temp;
 n1=sizeof l/sizeof l[0];
 n2=sizeof k/sizeof k[0];
 
 for(i=n1-1;i<n1;i++)
 {
  for(j=0;j<n;j++)
  {
   temp = l[i];
   l[i] = k[j];
   k[j] = temp;
  }
 }
 return ;
}
