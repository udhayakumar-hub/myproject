//Z.SHATHIK HUSSAIN

#include<stdio.h>
int main()
{
 char s[20];
 printf("Enter the string:\n");
 scanf("%s", s);
 printf("The entered string is %s\n",s);
 
 int i,alphabets=0,numbers=0,splc=0;
 
 for(i=0;s[i];i++)
 {
  if(s[i]>='A' || s[i]<='Z')
   alphabets++;
  else if(s[i]>='a' || s[i]<='z')
   alphabets++;
  else if(s[i]>='0' || s[i]<='9' )
   numbers++;
  else
   splc++;
 }
  
 printf("The number of alphabets,numbers and special characters presents in %s is:\n",s);
 printf("Alphabets = %d, Numbers = %d, Special characters = %d\n", alphabets,numbers,splc);
 
}
