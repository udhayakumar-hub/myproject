//NAME = NIKUNJ SOLANKI
//ID = V19CE6N5

#include<stdio.h>
#include<string.h>
int main()
{
	char s[20],d[20];

	printf("enter the string\n");
	scanf("%s",s);
	printf("enter the string\n");
	scanf("%s",d);
	
	char *p = strcat(d,s);
	printf("%s\n",p);
}
