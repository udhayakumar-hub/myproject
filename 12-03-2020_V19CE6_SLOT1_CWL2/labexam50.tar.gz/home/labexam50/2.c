//NAME = NIKUNJ SOLANKI
//ID = V19CE6N5

#include<stdio.h>
#include<string.h>
int main()
{
	char a[100];
	int n,s,i;	
	printf("enter the string\n");
	scanf("%s",s);
	
	n = sizeof a/sizeof a[0];
	printf("%S",n);
/*	
	for(i=0;i<n;i++)
	{
		if((i<'A')&&(i>'Z'))
		printf("%c",i);
		
	}
	
	
*/
}
