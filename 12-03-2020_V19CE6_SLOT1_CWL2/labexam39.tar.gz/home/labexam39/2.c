//Divya Susan Jose
//V19CE6D4
#include<stdio.h>
#include<string.h>
int main()
{
char str[20];
int i,j;
printf("Enter the string\n");
scanf("%s",str);
int l=strlen(str);
for(i=0,j=l-1;i<j;i++,j--)
{
if(str[i]==str[j])
continue;
else
break;
}
if(i<j)
printf("Given string is not palindrome\n");
else
printf("Given string is palindrome\n");
}
