//Divya Susan Jose
//v19CE6D4
#include<stdio.h>
char* my_strncpy(char*,char*,int);
int main()
{
char d[20],s[20];
int n;
printf("Enter the source string\n");
scanf("%s",s);
printf("Enter the n value\n");
scanf("%d",&n);
char* p=my_strncpy(d,s,n);
d[n]='\0';
printf("d=%s ",d);
printf("p=%s ",p);
}
char* my_strncpy(char* q,char* p,int n)
{
int i;
for(i=0;i<n&&p[i];i++)
q[i]=p[i];
for(;i<n;i++)
q[i]='\0';
return q;
}


