//santhosh kumar - v19ce6s7
#include<stdio.h>
char * mystrncpy(char *, char *,int );
int main()
{  int n,k;
char s[20],d[20];
printf("enter the string\n");
scanf("%s",d);

for(k=0;d[k];k++);

printf("enter the n values\n");
scanf("%d",&n);
if(k<n)
printf("u enter n values is higher than the str lenght\n");

char *t =mystrncpy(s,d,n);
printf("string of s[]=%s\n",t);

}

char * mystrncpy(char *s, char *d,int n)
{ int i;
for(i=0;i<n;i++)
 { s[i]=d[i];

  }
s[i]='\0';

return s;


}
