// santhosh kumar -v19ce6s7
#include<stdio.h>
int main()
{
int i,j,r;
char s[20];
// char s[]="radar"; 
  printf("enter the string\n");
  scanf("%s",s);
for(i=0;s[i];i++);
//printf("%d\n",i);

for(r=0,j=i-1;r<j;r++,j--)
{ 
  if(s[r]!=s[j])
  break;

 }
if((r==j)||(r>j))
printf("palindrome\n");
else
printf("not a palindrome\n");
}
