#include<stdio.h>
char* mystr(char*,char*);
int main()
{
char s[50],d[50];
printf("enter source\n");
scanf("%s",s);
printf("enter destination\n");
scanf("%s",d);
char *dest=mystr(d,s);
//d[i]='\0';
printf("the destionation %s\n",dest);
printf("the d =%s\n",d);
}
char* mystr(char*q,char*p)
{
int i,j;
for(i=0;q[i];i++);
for(j=0;p[j];j++,i++)
q[i]=p[j];
q[i]='\0';
return q;
}  
