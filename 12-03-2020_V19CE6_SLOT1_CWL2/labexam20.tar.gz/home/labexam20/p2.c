#include<stdio.h>
int main()
{
char a[50];
int i,alpha=0,num=0,sp=0;
printf("enter the string\n");
scanf("%s",a);
for(i=0;a[i];i++)
{
if(((a[i]>='a')&&(a[i]<='z'))||((a[i]>='A')&&(a[i]<='Z')))
alpha++;
else if((a[i]>='0')&&(a[i]<='9'))
num++;
else
sp++;
}
printf("the alpha present in %dtimes num present %d times sp present %d times\n",alpha,num,sp);
}
