#include<stdio.h>
int main()
{
int i,j,k,s[20];
printf("enter the str\n");
scanf("%s",s);
for(k=0;s[k];k++);

for(i=0,j=k-1;i<j;i++,j--)
{
if(s[i]==s[j])
break;
else if(s[i]!=s[j])
printf("not a palindrome\n");
}
if((i<j)||(j==i))
printf(" palindrome\n");
}

