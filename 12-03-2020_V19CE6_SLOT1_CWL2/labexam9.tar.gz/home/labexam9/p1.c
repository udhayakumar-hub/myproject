#include<stdio.h>
char fun_strncpy(char* d,char* s , int n );
int main()
{
char s[20],d[20],m;
int i,dl,sl,n;
printf("enter the sourcer\n");
scanf("%s",s);
printf("enter the destination\n");
scanf("%s",d);
for(i=0;s[i];i++);
i=sl;
for(i=0;d[i];i++);
i=dl;
n=sizeof d;
m=fun_strncpy(d,s,n);
printf("%s\n",m);
}
char fun_strncpy(char* d,char* s ,int n)
{
int i;
for(i=0;d[i]=s[i];i++);
return d;
}
