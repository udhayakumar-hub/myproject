//sangeetha.g-v19ce6s11//
#include<stdio.h>
int main()
{
char str[50];
char ch;
printf("enter the string\n");
scanf("%s",str);
if(ch>=A)&&(ch<=z)||(ch>=a)&&(ch>=z)
{
printf("alphabets\n")
else if(ch>='0')&&(ch<='9')
printf("numeric\n");
else
printf("special symbol\n");
}
}



 

