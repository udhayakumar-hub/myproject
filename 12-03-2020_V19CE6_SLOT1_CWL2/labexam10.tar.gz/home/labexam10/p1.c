//sangeetha.g-v19ce6s11:strcat//
#include<stdio.h>
char*my_strcat(char*p,char*q);
int main()
{
char s[20],d[20];
printf("enter the source sting\n");
scanf("%s",s);
printf("enter the destination sting\n");
scanf("%s",d);
char*p=my_strcat(d,s);
printf("d=%s\n",d);
printf("p=%s\n",p);
}
char*my_strcat(char*p,char*q)
{
int i,j;
for(i=o;q[i];i++)
{
for(j=o;j<i;j++)
q[i]==p[j];
q[i]='\0';
}
return q;
}





