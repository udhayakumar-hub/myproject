ZZ//Name: R.Naveen,Student Id: v19ce6n1
#include<stdio.h>
char *my_strcat(char *,char *);
int main()
{
int i,j;
char s[20],d[20];
printf("Enter the source string and destination string\n");
scanf("%s %s",s,d);
for(i=0;s[i];i++);
for(j=0;d[j];j++);
if((i+j+1)<20)
{
char *p=my_strcat(d,s);
printf("%s\n",p);
}
else
{
printf("destination string size is smaller and string cannot be caoncatenated\n");
return 0;
}
}
char *my_strcat(char *t,char *m)
{
int i,j,k;
for(i=0;t[i];i++);
for(j=i,k=0;m[k];k++,j++)
{
t[j]=m[k];
}
t[j]='\0';
return t;
}

