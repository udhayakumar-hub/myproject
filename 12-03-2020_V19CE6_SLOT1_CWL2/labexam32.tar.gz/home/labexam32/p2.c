//Name:R.Naveen,Id: v19ce6n1,username:labexam32
#include<stdio.h>
int main()
{
char str[30];
int i,alpha=0,num=0,symbols=0;
printf("Enter the string\n");
scanf("%s",str);
for(i=0;str[i];i++)
{
if(((str[i]>='a')&&(str[i]<='z'))||((str[i]>='A')&&(str[i]<='Z')))
alpha++;
else if((str[i]>='0')&&(str[i]<='9'))
num++;
else
symbols++;
}
printf("no.of alphabets: %d\n",alpha);
printf("no.of numeric characters: %d\n",num);
printf("no.of special symbols: %d\n",symbols);
}

