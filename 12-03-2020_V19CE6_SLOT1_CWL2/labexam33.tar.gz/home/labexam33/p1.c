//mangaiyarkarasi
//v19ce6m4
#include<stdio.h>
char* my_strncpy(char*,char*,int);
int main()
{
int a[50],b[50];
int n;
printf("enter the source string..\n");
scanf("%s",a);
printf("enter the destination string..\n");
scanf("%s",b);
printf("enter the num..\n");
scanf("%d",&n);
char*cp=my_strncpy(b,a,n);
printf("%s",cp);
}
char*my_strncpy(char*b,char*a,int n)
{
int i,j;
for(i=0;a[i];i++)
{
for(j=0;j<n-i;j++)
b[i]=a[j];
}
return b;
}
