//mangaiyarkarasi 
//v19ce6m4
#include<stdio.h>
int main()
{
char a[50];
int i,j,m;
printf("enter the string..\n");
scanf("%s",a);
for(m=0;a[m];m++);
for(i=0,j=m-1;i<=j;i++,j--)
{
if(a[i]==a[j])
continue;
else
break;
}
if(j<i)
printf("it is palindrome\n");
else
printf("not a palindrome\n");
}


