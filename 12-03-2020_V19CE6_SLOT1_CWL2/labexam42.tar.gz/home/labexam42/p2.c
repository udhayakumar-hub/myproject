//Lubna K
//V19CE6L2
#include<stdio.h>
int main()
{
char a[15];
int i,c,l,n,s;

n=sizeof a/sizeof a[0];
printf("enter string\n");

scanf(" %s",a);
for(l=0;a[l];l++);

l=n=s=0;
for(i=0;a[i]; i++)
{
if((a[i]>='a'&& a[i]<='z')||(a[i]>='A' &&a[i]<='Z'))
{
l++;
}
else if((a[i]>='0' &&a[i]<='9'))
{
n++;
}
else  
{
s++;
}
}
printf("alp=%d, nums=%d, special=%d\n",l,n,s);
}

