//Lubna k
//V19CE6L2
#include<stdio.h>
char* my_strcat(char*, char*);
int main()
{
char s[20],d[20];
int n;
printf("enter source string\n");
scanf(" %[^\n]",s);
printf("enter destination string\n");
scanf(" %[^\n]",d);
char* p=my_strcat(d,s);

printf("source=%s\np=%s\n",s,p);

}
char* my_strcat(char* q,char* p)
{
int i,j;
for(i=0;q[i];i++);
for(j=0;p[j];j++,i++)

q[i]=p[j];
q[i]='\0';
return q;

}
