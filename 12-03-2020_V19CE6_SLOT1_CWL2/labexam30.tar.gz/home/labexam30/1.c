//name:a.athivel
//batch:v19ce6a1


#include<stdio.h>
#include<string.h>
int main()
{
char a[20];
int i,A=0,a=0,s=0,n=0,w=0;
printf("enter the string with some special characters\n");
scanf("%s",a);
printf("strings=%s",a);
for(i=0;a[i];i++)
{
if((a[i]>='A')&&(a[i]<='Z'))
a++;
else if((a[i]>='a')&&(a[i]<='z'))
A++;
else if((a[i]>='0')&&(a[i]<='9'))
n++;
else
s++;
}
w=a+A;
printf("NO OF ALPHABETS=%d ,NO OF SPECIAL CHARACTER=%d  ,NUMERIC CHARACTER=%d",w,s,n);
printf("\n");
}




