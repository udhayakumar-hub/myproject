//name a.athivel
//batch:v19ce6a1

#include<stdio.h>
#include<string.h>
char my_strcat(char *p,char *q);
int main()
{
char d[10],s[10];
printf("enter the source\n");
scanf("%s",d);
printf("enter the string\n");
scanf("%s",s);
 char p =my_strcat(d,s);
printf("string=%s",);
}
char my_strcat(char *p,char *q)
{
int i,j;
for(i=0;p[i];i++);

i++;
for(j=i;q[j];j++)
{
p[i]=q[j];
}
return p;
}

