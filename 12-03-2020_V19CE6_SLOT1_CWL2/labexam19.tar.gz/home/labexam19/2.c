//ASHIL SHAJI- V19CE6A3
#include<stdio.h>
int main()
{
	int i,j,l;
	char s[100];
	printf("enter the string:\n");
	scanf("%[^\n]",s);
	for(l=0;s[l];l++);
	for(i=0,j=l-1;i<j;i++,j--)
	{
		if(s[i]!=s[j])
			break;
	}
	if(i<j)
		printf("the given string is not pallindrome.\n");
	else
		printf("the given string is pallindrome.\n");
}

