//ASHIL SHAJI -V19CE6A3
#include<stdio.h>
#include<stdlib.h>
char *my_strncpy(char*p,char*q,int n);
int main()
{
	int l,n,a;
	char d[100],s[100];
	printf("enter the source string:\n");
	scanf("%[^\n]",s);
	printf("the enterd source string is\n");
	printf("%s",s);
	printf("\n");
	printf("enter the number\n");
	scanf("%d",&n);
        for(l=0;s[l];l++);
        if(l<n)
        {
        printf("enter the valid number\n");
        return 0;
        }
        char *x=my_strncpy(d,s,n);
	d[n]='\0';
	printf("the copied destination string data-->%s\n",x);

}
char *my_strncpy(char*p,char*q,int n)
{
	int i;
	for(i=0;i<n;i++)
		p[i]=q[i];
	for(;i<n;i++);
	p[i]='\0';
	return p;
}
