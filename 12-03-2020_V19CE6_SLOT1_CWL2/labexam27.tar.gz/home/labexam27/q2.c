//SUKRUTHSOORYA
//V19CE6S1
#include<stdio.h>
int main()
{
char a[10];
int i,j,k; 
printf("enter the string\n");
scanf("%s",a);
for(i=0;a[i];i++);
for(j=0,k<i-1;j<k;j++,k--)
{
if(a[j] == a[k])
continue;
else
printf("the given string is not palindrome\n");
return 0;
}
printf("the given string is palindrome\n");
}







/*#include<stdio.h>
int main()
{
char a[10];
int i,j,n;
printf("enter the string\n");
scanf("%s",a);
n= sizeof a/ sizeof a[0];
for(i=0,j=n-1;i<j;i++,j--)
{
if (a[i]!= a[j])
break;
else
continue;
printf(" palindrome\n");
return 0;
}
printf("not palindrome\n");
}*/



