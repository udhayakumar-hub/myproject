//SUKRUTH SOORYA KK
//V19ce6s1

#include<stdio.h>
#include<string.h>
char*  my_strncpy(char* ,char* ,int );
int main()
{
char s[20],d[20];
int n;
printf("enter the source string\n");
scanf("%s",s);
printf("enter the destination string\n");
scanf("%s",d);
printf("enter the value of n\n");
scanf("%d ",&n);
char * q= my_strncpy(d,s,n );
printf("after copy the string is:%s",q);
}
char* my_strncpy(char *p, char *q, int n)
{
int i;
for(i=0;(i<n)&&p[i];i++)
q[i]=p[i];
//q=p+i;
q[i]='\0';
return q;
}
