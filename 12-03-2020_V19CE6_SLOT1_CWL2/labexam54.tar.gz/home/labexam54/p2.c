/*vectorid-v19ce6s12
Name:Ajeeh kumar.S */
#include<stdio.h>
#include<string.h>
int main()
{
char a[50];
int i,n,b,num,sp;
printf("Enter the string\n");
scanf("%s",a);
for(i=0,b=0,num=0,sp=0;a[i];i++)
{
if(((a[i]>='a'))&&(a[i]<='z'))
{
b++;
}
else if((a[i]>='0')&&(a[i]<='9'))
{
num++;
}
else{ 
sp++;
}
}
printf("alphabets is: %d\n",b);
printf("numbers is:%d\n",num);
printf("special char:%d\n",sp);
printf("\n");
}

