/*ajeeth kuamr.S
v19ce6s12*/
#include<stdio.h>
char str(char * ,char * );
int main()
{
char s[20],d[20];
printf("Enter the source string\n");
scanf("%s",s);
printf("Enter the des string\n");
scanf("%s",d);
char *str=strcat(d,s);
printf("String is: %s",str);
}
char str(char * p, char * q)
{
int i,j;
for(i=0;q[i];i++);
for(j=0;p[j];j++)
q[i]=p[i];
q[i]='\0';
return p;
}

