//V19CE5A19
//ALAN SAJI
#include<stdio.h>
char d[10], s[10]={"vector"};
int n,i;
printf("Enter the number\n");
scanf("%d",&n);
char *my_strncpy(char *, char *, int *);

int main()
{
my_strncpy(char *d, char *s, int *n);
printf("%s",d);
}

char my_strncpy(char *,char *,int *)
{
	for(i=0;s[i];i++)
	{
	if(i<n)
	d[i]=s[i];
	else
	break;
}
