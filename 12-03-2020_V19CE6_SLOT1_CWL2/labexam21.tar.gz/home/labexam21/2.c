//V19CE5A19
//ALAN SAJI
#include<stdio.h>
int main()
{
int i=0,j,k,c=0;
char a[20];
printf("Enter the String\n");
scanf("%s",a);

for(k=0;a[k];k++);
for(j=k;a[i];j--)
{
for(i=0;a[i];i++)
{
if(a[i]!=a[j])
break;
}
}
if(i<j)
printf("not palindrone\n");
else
printf("palindrome\n");
}
