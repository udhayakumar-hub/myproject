//M.anusha
//v19ce6m3
#include<stdio.h>
int main()
{
char s[20];
printf("enter string\n");
scanf("%s",s);
int a=0,n=0,c=0;
int i;
for(i=0;s[i];i++)
{
if(((s[i]>='a')&&(s[i]<='z'))||((s[i]>='A')&&(s[i]<='Z')))
a++;
else if(s[i]>='0'&&s[i]<='9')
n++;
else
c++;

}
printf("no. of alphabets=%d\n",a);
printf("no. of numericals=%d\n",n);
printf("no. of special characters =%d\n",c);

}
