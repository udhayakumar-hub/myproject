//M.anusha
//v19ce6m3
#include<stdio.h>
char* my_strcat(char*, char*);
int main()
{
char s[20],d[20];
printf("enter source and destination strings\n");
scanf("%s %s",s,d);
char*x=my_strcat(d, s);
printf("x=%s\n",x);
printf("d=%s\n",d);


}
char* my_strcat(char* q, char* p)
{
int i,j;
for(i=0;q[i];i++);
for(j=0;p[j];j++)
{
q[i+j]=p[j];

}
q[i+j]='\0';
return q;

}
