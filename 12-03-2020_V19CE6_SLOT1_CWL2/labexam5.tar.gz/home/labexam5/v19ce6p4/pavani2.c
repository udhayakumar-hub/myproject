#include<stdio.h>
#include<string.h>
int main()
{
char s[20];
int i,j,len;
printf("enter the string\n");
scanf("%s",s);
for(i=0;s[i];i++);
printf("length of the string: %d",i);
len=i;
for(i=0,j=len-1;i<j;i++,j--)
{
if(i!=j)
break;
}
if(i<j){
pritnf("palindrome\n");}
else
printf("not palindrome\n");
}

