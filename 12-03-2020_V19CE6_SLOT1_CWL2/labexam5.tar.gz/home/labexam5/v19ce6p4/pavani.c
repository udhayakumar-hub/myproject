#include<stdio.h>
char my_strncpy(char *,char *);
int main()
{
char s[20],d[20];
int n;
printf("enter the string\n");
scanf("%s",s);
printf("enter n value\n");
scanf("%d",&n);
char *p=my_strncpy(d,s,n);

printf("d=%s",d);
printf("p=%s",p);
}
char *my_strncpy(char *q,char *p,int n)
{
int i;
for(i=0;(i<n)&& p[i];i++)
q[i]=p[i];
q[i]='\0';
return q;
}

