// v.chiranjeevi, v19ce6c2
#include<stdio.h>
char *my_strncpy(char*,char*,int);
int main()
{
	char a[20];
	char b[20];
	int n;
	printf("enter the main string\n");
	scanf("%s",a);
	printf("enter the no.of charactera to copy\n");
	scanf(" %d",&n);
	char *p=my_strncpy(b,a,n);
	printf("main string-->%s\n",a);
	printf("copied string-->%s\n",b);
	printf("pointer-->%s\n",p);
}
char *my_strncpy(char *b,char *a,int n)
{
	int i=0;
	for(i=0;i<n&&a[i];i++)
	b[i]=a[i];
	b[i]='\0';
	return b;
}
