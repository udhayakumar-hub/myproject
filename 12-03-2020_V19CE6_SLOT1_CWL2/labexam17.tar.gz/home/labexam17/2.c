//v.chiranjeevi, v19ce6c2
#include<stdio.h>
int main()
{
char a[20];
char b[20];
int i,j,n;
printf("enter the string\n");
scanf("%s",a);
for(n=0;a[n];n++);
for(j=0,i=n-1;j<n;j++,i--)
{
b[j]=a[i];
}
b[j]='\0';
for(i=0;i<n;i++)
{
if(a[i]!=b[i])
break;
}
if(i==n)
printf(" given string is palandorme\n");
else
printf("given string is not palandrome\n");
}

