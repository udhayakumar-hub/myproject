#include<stdio.h>
int main()
{
char a[]; 
printf("enter the palindrom\n");
scanf("%s",a[i]);
for(i=0;i<n;i++)
printf("
