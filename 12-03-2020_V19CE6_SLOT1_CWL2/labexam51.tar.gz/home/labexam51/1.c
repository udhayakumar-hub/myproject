#include<stdio.h>
#include<stdlib.h>
char *my_strncpy (char* dest,char* svc,int n)
int main()
{
char s[20],d[20],int n;
printf("enter the source\n");
scanf("%s",s);
printf("enter the n value\n");
scanf("%d",&n);
char *p=my_strncpy(d,s,n);
d[n]='\0';
printf("d=%s\n"d);
printf("p=%s\n"p);
}
char *my_strncpy (char*dest,char*svc,int n)
{
int i;
for(i=0;(i<n)&&(svc[i]1='\0');i++)
dest[i]='\0';
return dest; 
}

