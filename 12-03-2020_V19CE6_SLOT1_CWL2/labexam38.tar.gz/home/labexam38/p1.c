//name:Tamilarasi//
//batch id:v19ce6t1//
#include<stdio.h>
char my_strcat(char *s1,char s2);
int main()
{
char s1[70],s2[50];
int i,s;
printf("enter the  string s1");
for(i=0;i<10;i++);
scanf("%c",&s1[i]);
printf("enter the string s2");
for(i=0;i<10;i++)
scanf("%c",&s2[i]);
s=my_strcat(s1);
printf("%s",s);
}
char my_strcat(char *s1,char *s2);
{
int i;
for(i=0;s1[i];i++)
{
for(i=0;s2[i];i++)
s1[i]=s2[i];
printf("%s",s1[i]);
}
return s1;
}

