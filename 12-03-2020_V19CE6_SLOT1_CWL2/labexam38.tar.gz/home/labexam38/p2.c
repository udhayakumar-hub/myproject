//name:Tamilarasi.A//
//batch id:v19ce6t1//
#include<stdio.h>
int main()
{
char a[]="tamil#123";
int i,alpha=0,digits=0,spcl=0,lowecase=0;
for(i=0;a[i];i++)
printf("%c",a[i]);
printf("\n");
for(i=0;a[i];i++)
{
if((a[i]>='A')&&(a[i]<='Z')||(a[i]>='a')&&(a[i]<='z'))
alpha++;
else if((a[i]>='0')&&(a[i]='9'))
digits++;
else
spcl++;
}
printf("alpha=%d,digits=%d,spcl=%d",alpha,digits,spcl);
}
