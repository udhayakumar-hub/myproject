i//v19ce6j3 J.skandakumar
#include<stdio.h>
char*my_strncpy(char*,char*);
int main()
{
char s[50],d[50];
printf("enter the source string\n");
scanf("%s",s);
printf("enter the destination string\n");
scanf("%s",d);
char*=my_strncpy(d,s)
if(src=dst)
{
printf("copy the string\n");
else
printf("not copy the string\n");
}
char*mystrncpy(char*d,char*s);
int i,p,q;
for(i=0;p[i];i++)
p[i]=q[i];
q[i]='\0';
p=p+i;
return q;
}



