/*v19ce6j3 
name J.skandakumar*/
#include<stdio.h>
#include<string.h>
int main()
{
int i,j;
char a[50];
printf("enter the string\n");
scanf("%s",a[i]);
for(i=0,j=i-1;i<j;i++,j--)
{
if(a[i]==a[j])
{
continue;
else
break;
}
if(i<j)
printf("string is palindrome\n");
else
printf("string os not a palindrome\n");
}
