//P.kotteswaran
//v19ce6p3
#include<stdio.h>
int main()
{
int i,n,j;
char s[10];
printf("Enter the string\n");
scanf("%s",s);
for(n=0;s[n];n++);
for(i=0,j=n-1;s[i];i++,j--)
{
if(s[i]!=s[j])
break;
} 
if(i==n)
printf("%s is palindrome\n",s);
else 
printf("%s is not palindrome\n",s);
}
