//P.kotteswaran
//v19ce6p3
#include<stdio.h>
char *strncpy(char *,char*,int);
int main()
{
char s[10],d[10];
int n;
printf("Enter the sourse string\n");
scanf("%s",s);
printf("Sourse string :%s\n",s);
printf("Enter the n value\n");
scanf("%d",&n);
char *r=strncpy(d,s,n);
printf("Destination string %s\n",r);
}
char *strncpy(char *q,char *p,int n)
{
int i;
for(i=0;i<n;i++)
q[i]=p[i];
q[i]='\0';
return q;
}

