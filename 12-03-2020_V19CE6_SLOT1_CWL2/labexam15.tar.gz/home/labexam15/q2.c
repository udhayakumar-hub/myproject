#include<stdio.h>
#include<string.h>
int main()
{
int n,temp,i,j;
char a[20];
printf("enter the string\n");
scanf("%d");
for(i=0;i<10;i++)
{
for(j=10;j>0;j--)
{
temp=i;
i=j;
j=temp;
if(i=j)
printf("it is a palindrome\n");
else
printf("it is not a palindrome\n");
}
}
}

