//Dinesh Kumar.M
//v19ce6d5
#include<stdio.h>
#include<string.h>
int main()
{
char s[59],d,p;
printf("enter the source\n");
scanf("%d",&s);
char *q=(int*q,int s);
for(j=0;p[j];j++)
printf("%s",s);
printf("%s",d);
printf("%s",p);
printf("\n");
}
int strncpy(int*q,int s)
{
int j;
for(j=0;p[j];j++)
d[j]=s[j];
d[j]='\0';
return(q,s);
return s;
}


