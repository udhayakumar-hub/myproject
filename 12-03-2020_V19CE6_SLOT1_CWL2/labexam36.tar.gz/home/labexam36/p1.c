/*name: NIRMAL RAGAVAN R
ID:V19CE6N3*/
#include<stdio.h>
#include<string.h>
char *fun(char *,char *);
main()
{
char  a[50],b[50];
printf("enter the source string\n");
scanf("%s",a);
printf("enter the destion string\n");
scanf("%s",b);
char *x=fun(a,b);
printf("b=%s\n",b);
printf("x=%s\n",x);
}
char *fun(char *p,char*q)
{
int i,j;
for(i=0;p[i];i++);
i++;
for(j=0;q[j];j++,i++)
q[i]=p[j];
q[i]='\0';
return q;
}
