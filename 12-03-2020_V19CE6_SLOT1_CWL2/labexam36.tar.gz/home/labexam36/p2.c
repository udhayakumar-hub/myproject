/*NAME:NIRMAL RAGAVAN
ID:V19CE6N3*/
#include<stdio.h>
main()
{int i,j,b=0,c=0,d=0;
char a[50];
printf("enter the string");
scanf("%s",a);
for(i=0;a[i];i++);
j=i;
for(i=0;i<j;i++){

if(((a[i]>='A')&&(a[i]<='Z'))||((a[i]>='a')&&(a[i]<='z')))
d++;
else if((a[i]>='0')&&(a[i]<='9'))
b++;
else
c++;
}
printf("no of alphabets : %d\n",d);
printf("no of numerical character : %d\n",b);
printf("no of pecial symbols : %d\n",c);
}
