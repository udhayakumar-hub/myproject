/************************ M.chandrasekar   V19ce6c1  *********************/
/* strcat

#include<stdio.h>
char *my_strcat(char *p,char *q,int);
//#include<string.h>
int main()
{
char d[50];
char s[20];
int i;
printf("enter the destination string\n");
scanf("%s",d);
printf("enter the src string\n");
scanf("%s",s);
for(i=0;d[i];i++);
int num=d[i];

char* str=my_strcat(d,s,num);
printf("%s",str);
}

char *my_strcat(char *p,char *q,int num)
{
static int i,j,c=0;
int dl,sl,free;
int n=sizeof p/sizeof p[0];
for(i=0;p[i];i++)
dl=c++;
for(i=0;q[i];i++)
sl=c++;
free=num - dl;
for(i=0;i<n;i++)
{
if(sl<free)
{
printf("insufficient memory\n");
}
break;
}
for(i=dl+1,j=0;p[i]=q[j];i++,j++);
return p;
}*/
#include<stdio.h>
int main()
{
int i,n;
int c=0;
int k=0;
int j=0;
char a[100];
printf("enter the string\n");
scanf("%s",a);
n= sizeof a/ sizeof a[0];
for(i=0;i<n;i++)
{
if(((a[i]>='A')&&(a[i]<='Z'))||((a[i]>='a')&&(a[i]<='z')))
c++;
 if((a[i]>='1')&&(a[i]<='9'))
j++;
else
k++;
break;
}
printf(" the no.of alphabates is %d\n",c);
printf(" the no.of numberic value or digit is %d\n",j);
printf(" the no.of symbols is %d\n",k);
}































