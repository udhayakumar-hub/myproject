//v19ce6j2(jeron melva.s.q)
#include<stdio.h>
int main()
{
char a[20];
int i,n,vowels=0,consonent=0,digit=0,specialcharacter=0;
for(i=0;a[i];i++);
//scanf("%s",&a[i]);	
printf("enter the character n\n");
scanf("%s",&n);
for(;a[i];i++)
{
if((a[i]='A')||(a[i]='E')||(a[i]='I')||(a[i]='O')||(a[i]='U')||(a[i]='S')||(a[i]='a')||(a[i]='e')||(a[i]='i')||(a[i]='o')||(a[i]='u')||(a[i]='s'))
vowels++;
else if(((a[i]<='A')&&(a[i]>='Z'))||((a[i]='a')&&(a[i]='z')))
consonent++;
else if(a[i]<='0'||a[i]>='9')
digit++;
else
{
printf("not a special character\n"); 
specialcharacter++;
}
}
}
