//V19ce6j2(Jeron melva s.q)
#include<stdio.h>
char*my_strcat(char*p,char*q);
int main()
{
char a[20],b[20];
printf("enter the a and b string\n");
scanf("%s %s",a,b);
char*q=my_strcat(a,b);
printf("%s",q);
}
char*my_strcat(char*p,char*q)
{
int i,j;
for(i=0;q[i];i++);
for(j=0;p[j];j++)
q[i]=p[j];
q[i]='\0';
return q;
}
