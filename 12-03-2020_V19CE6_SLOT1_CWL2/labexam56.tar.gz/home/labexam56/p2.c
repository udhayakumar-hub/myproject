//v19ce6s13 B.Santhiya
#include<stdio.h>
int main()
{
char a[20];
int i,alp=0,num=0,spl=0;
printf("Enter the string\n");
scanf("%s",a);
for(i=0;a[i];i++)
{
if(((a[i]>='A')&&(a[i]>='Z'))||((a[i]>='a')&&(a[i]>='z')))
alp++;
else if((a[i]>='0')&&(a[i]<='9'))
num++;
else 
spl++;
}
printf("No.of Alphabets=%d\n",alp);
printf("No.of numeric constants=%d\n",num);
printf("No.of special characters=%d\n",spl);
}
