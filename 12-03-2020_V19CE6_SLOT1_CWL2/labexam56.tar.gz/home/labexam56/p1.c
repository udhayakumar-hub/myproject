//v19ce6s13   B.santhiya
#include<stdio.h>
char *my_strcat(char*,char*);
int main()
{
char s[50],d[50];
printf("Enter source string\n");
scanf("%s",s);
printf("Enter destination string\n");
scanf("%s",d);
char *r=my_strcat(s,d);
printf("d=%s\n",r);
printf("s=%s\n",s);
}
char *my_strcat(char *p,char *q)
{
int i,sl,dl,j;
for(sl=0;p[sl];sl++);
for(dl=0;q[dl];dl++);
for(i=dl,j=0;p[j];i++,j++)
q[i]=p[j];
q[i]='\0';
return q;
}
