#include<sstdio.h>
int main()
{
int n;
char s[50];
char ch;
printf("enter string \n");
scanf("%s",&s);
printf("enter alphabets\n");
scaanf("%c,&c);
printf("enter numerical characters\n");
scaanf("%c,&c);
printf("special symbols\n");
scaanf("%c,&c);
for(i=0;i<n;i++)
{
if((ch>='A')&&(ch<='z'))||((ch>='a')&&(ch<='z'))
printf("display alphabets\n");
elseif((ch>='0')&&(ch<='9'))
printf("display numerical chaaracters\n");
if(ch='+','-','*','%','/')
printf("display special symbols");
}

