// s.lingeshkumar
// v19ce6l1

#include<stdio.h>
#include<string.h>
int strcat(int *p,int s);
int main()
{
char s[20];
printf("enter source\n");
scanf("%s",&s);
char *p=(int *p,int s);
print("s=%s\n",s);
print("d=%s\n",d);
print("p=%s\n",p);
int strcat(int *p,int s)
{
int i;
for(i=0;s[i];i++)
d[i]=s[i];
d[i]='\0';
return (p,s);
}
return s;
}


