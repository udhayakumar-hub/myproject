//v19ce6t2 tamilselvi.c
// palindrome or not
#include<stdio.h>
#include<string.h>
int main()
{
int a[]={"madam"};
int i,j,k,ele,n;
ele=sizeof a/sizeof a[0];
for(a[i]=0;a[i]<ele;a[i]++)
printf("enter the string \n:",n);
{
for(a[i]=0;a[i]<ele;a[i]++)
{
for(a[j]=0;a[j]>ele;a[j]--)
{
if(a[i]==a[j])
{
printf("%c",a[i]);
else
printf("%c",a[2]);
else
printf("%c",a[j]);
}
}
}
}
} 
