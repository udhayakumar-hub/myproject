#include<stdio.h>
#include<string.h>
void fun(s1[],s2[])
int main()
{
int s1[60],s2[90];
printf("enter the elements in the string\n",s1,s2);
fun();
printf("the copied string is");
return 0;
void fun (int a,int b)
{
 strncpy(s1,s2);

}


}
