// v19ce6v1
//prog2
#include<stdio.h>
int main()
{
char a[10];
char ch;
int n,i,vowels=0,consonent=0,digits=0,specialcharacter=0;
n=sizeof a/sizeof a[0];
printf("Enter the character\n");
for(i=0;i<n;i++)
scanf("%c",a+i);
printf("\n");
if((a[i]=='a')||(a[i]=='e')||(a[i]=='i')||(a[i]=='o')||(a[i]=='u')||(a[i]=='A')||(a[i]=='E')||(a[i]=='I')||(a[i]=='O')||(a[i]=='U'))
vowels++;
else if(((a[i]>='A')&&(a[i]<='Z'))||((a[i]>='a')&&(a[i]<='z')))
consonent++;
else if ((a[i]>='0')&&(a[i]<='9'))
digits++;
else 
specialcharacter++;
printf("v=%d c=%d s=%d d=%d\n",vowels,consonent,specialcharacter,digits);
}



