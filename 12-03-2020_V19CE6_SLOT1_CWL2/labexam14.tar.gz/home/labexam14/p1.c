// v19ce6v1
// 1 prog


#include<stdio.h>
char* my_strcat(char* p,char* q);
int main()
{
char s[10],d[10];
printf("Enter the source string\n");
scanf("%s",s);
printf("Enter the destination string\n");
scanf("%s",d);
char* p=my_strcat(d,s);
printf("d=%s",d);
printf("p=%s",p);
}
char*my_strcat(char* p,char* q)
{
int i,j;
for(i=0;q[i];i++)
{
for(j=0;p[j];j++)
{
q[i]==p[j];
q[i]='\0';
}
return p;
}
}









