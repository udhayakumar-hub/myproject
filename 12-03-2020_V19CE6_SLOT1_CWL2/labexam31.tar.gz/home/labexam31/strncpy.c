#include<stdio.h>
int main()
{
   int i,n,t;
  printf("enter the value\n");
  scanf("size of 0/ size of a()");
   while 
      { i=0;i<n,i++ }
   printf( "enter the strncpy()");
  printf("return value o");
  printf( "strncpy");
}
