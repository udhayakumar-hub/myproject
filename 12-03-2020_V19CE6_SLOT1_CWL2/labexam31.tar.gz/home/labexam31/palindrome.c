#include<stdio.h>
int main()
{
  printf("enter the n value");
  printf("%d/n");
}
  for(i=0;i<n;i++)
  {
    printf("enter the 5 strings");
    scanf("palindrome (or) not");
    printf("%d\n");
} 
